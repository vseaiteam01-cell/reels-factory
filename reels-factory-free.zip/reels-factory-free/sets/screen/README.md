# Editor screen

The desktop editor Reels Factory is promoted with, built around your clip:
agent cursors cutting one timeline, a media pool, the source viewer, the
program window, scopes, meters and an export bar. 2880x1800, 42 seconds.

```bash
python screen.py my-video.mp4 --movik my-movik.mp4 --out my-screen.mp4
```

`--movik` puts your movik in the program window; without it the program window
plays your clip, cropped to vertical. Twenty frames of your video fill the
media pool.

It is an HTML composition (`template/index.html`) rendered by HyperFrames: node
and a headless Chrome, which the first run downloads once. A render takes
15-30 minutes on a laptop.
