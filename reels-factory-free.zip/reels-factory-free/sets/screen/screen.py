# -*- coding: utf-8 -*-
"""The editor screen from your video: the screen Reels Factory is promoted with.

    python screen.py my-video.mp4 [--movik my-movik.mp4] [--out my-screen.mp4]

A 2880x1800 desktop editor, 42 seconds: your clip in the media pool and the
source viewer, your movik (or your clip) playing in the program window, agent
cursors cutting one timeline, scopes, meters, an export bar. Rendered by
HyperFrames (node and a headless Chrome; the first run downloads Chrome once).
"""
import os, shutil, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "template")
CLI = "hyperframes@0.9.45"
DUR = 42.0


def arg(name, default=None):
    for i, a in enumerate(sys.argv):
        if a == name and i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return default


def ff(*a):
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y"] + list(a), check=True)


def duration(path):
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of",
                        "csv=p=0", path], capture_output=True, encoding="utf-8", errors="replace", check=True)
    return float(p.stdout.strip())


def ascii_dir():
    """A temp folder with Latin letters only: the render tools trip on others."""
    base = tempfile.gettempdir()
    try:
        base.encode("ascii")
    except UnicodeEncodeError:
        base = next((d for d in (os.environ.get("PUBLIC"), "C:\\Users\\Public", "/tmp")
                     if d and os.path.isdir(d)), base)
    return tempfile.mkdtemp(prefix="screen_", dir=base)


def main():
    flags = {"--movik", "--out"}
    vals = {sys.argv[i + 1] for i, a in enumerate(sys.argv[:-1]) if a in flags}
    args = [a for a in sys.argv[1:] if not a.startswith("--") and a not in vals]
    if not args:
        raise SystemExit("a path to a video is required: python screen.py my-video.mp4")
    video = os.path.abspath(args[0])
    out = os.path.abspath(arg("--out", "my-screen.mp4"))
    movik = arg("--movik")
    t0 = time.time()
    work = ascii_dir()
    proj = os.path.join(work, "screen")
    shutil.copytree(TEMPLATE, proj)
    own = os.path.join(proj, "assets", "own")
    os.makedirs(os.path.join(own, "thumbs"), exist_ok=True)

    print("1/3 your clip into the screen", flush=True)
    src_len = duration(video)
    loop = ["-stream_loop", "-1"] if src_len < DUR else []
    ff(*loop, "-i", video, "-t", "%.1f" % DUR, "-vf", "scale='min(1920,iw)':-2,fps=30",
       "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-an",
       os.path.join(own, "source.mp4"))
    if movik:
        ml = duration(movik)
        ff(*(["-stream_loop", "-1"] if ml < DUR else []), "-i", os.path.abspath(movik), "-t", "%.1f" % DUR,
           "-vf", "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,fps=30",
           "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-an",
           os.path.join(own, "movik.mp4"))
    else:
        ff(*loop, "-i", video, "-t", "%.1f" % DUR,
           "-vf", "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,fps=30",
           "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-an",
           os.path.join(own, "movik.mp4"))
    for i in range(1, 21):
        at = min(src_len - 0.1, src_len * (i - 0.5) / 20)
        ff("-ss", "%.2f" % at, "-i", video, "-frames:v", "1", "-vf",
           "scale=480:270:force_original_aspect_ratio=increase,crop=480:270", "-q:v", "3",
           os.path.join(own, "thumbs", "t%02d.jpg" % i))

    print("2/3 rendering the screen: the longest part, 15-30 minutes", flush=True)
    tmp_out = os.path.join(work, "screen.mp4")
    p = subprocess.run([shutil.which("npx") or "npx", "--yes", CLI, "render", "-o", tmp_out, "--quality", "looks"],
                       cwd=proj, capture_output=True, encoding="utf-8", errors="replace")
    if p.returncode != 0 or not os.path.exists(tmp_out):
        tail = "\n".join((p.stdout + p.stderr).strip().splitlines()[-12:])
        raise SystemExit("the render failed:\n" + tail)

    print("3/3 the file", flush=True)
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    shutil.move(tmp_out, out)
    shutil.rmtree(work, ignore_errors=True)
    print("done: %s, %.1f s, %.1f MB, %.1f min" % (os.path.relpath(out), duration(out),
          os.path.getsize(out) / 1048576.0, (time.time() - t0) / 60), flush=True)


if __name__ == "__main__":
    main()
