# -*- coding: utf-8 -*-
"""Экран монтажки: ваше видео внутри окна программы.

Самодостаточный набор: ни конвейера, ни библиотеки эффектов не нужно, весь
интерфейс рисуется здесь и читается глазами.

    python3 montazhka.py my-video.mp4 [--out my-montazhka.mp4] [--window 0.86]
"""
import os, sys, json, math, subprocess, tempfile, shutil

W, H, FPS = 1080, 1920, 30
BG = (28, 20, 42)
PANEL = (40, 28, 56)
EDGE = (70, 52, 96)
LIME = (60, 255, 182)
ACC = (255, 59, 123)
NAME = "REELS FACTORY"


def run(cmd, check=True):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if check and p.returncode != 0:
        raise SystemExit((p.stderr or p.stdout)[-800:])
    return p.stdout + p.stderr


def probe(path):
    d = json.loads(run(["ffprobe", "-v", "error", "-print_format", "json",
                        "-show_format", "-show_streams", path]))
    v = next((s for s in d["streams"] if s["codec_type"] == "video"), None)
    if v is None:
        raise SystemExit("the file has no video track: " + path)
    a = next((s for s in d["streams"] if s["codec_type"] == "audio"), None)
    return {"dur": float(d["format"]["duration"]), "w": int(v["width"]),
            "h": int(v["height"]), "audio": a is not None,
            "vertical": int(v["height"]) > int(v["width"])}


def prepare(src, info, tmp, want):
    """Prepares the vertical base of the needed length together with the audio."""
    vf = ("crop=ih*9/16:ih,scale=%d:%d" % (W, H)) if not info["vertical"] else \
         ("scale=%d:%d" % (W, H))
    out = os.path.join(tmp, "base.mp4")
    cmd = ["ffmpeg", "-nostdin", "-v", "error", "-y", "-t", "%.2f" % want, "-i", src,
           "-vf", vf + ",fps=%d" % FPS, "-c:v", "libx264", "-preset", "veryfast",
           "-crf", "16", "-pix_fmt", "yuv420p"]
    cmd += ["-c:a", "aac", "-b:a", "192k", "-ac", "2"] if info["audio"] else ["-an"]
    run(cmd + [out])
    return out


def _box(img, x, y, w, h, col, a=1.0, r=16):
    import cv2
    x, y, w, h = int(x), int(y), int(w), int(h)
    if w < 4 or h < 4:
        return img
    r = int(min(r, (min(w, h) - 1) // 2))
    ov = img.copy()
    cv2.rectangle(ov, (x + r, y), (x + w - r, y + h), col, -1)
    cv2.rectangle(ov, (x, y + r), (x + w, y + h - r), col, -1)
    for cx, cy in ((x + r, y + r), (x + w - r, y + r),
                   (x + r, y + h - r), (x + w - r, y + h - r)):
        cv2.circle(ov, (cx, cy), r, col, -1, cv2.LINE_AA)
    return cv2.addWeighted(ov, a, img, 1 - a, 0)


def _text(img, s, x, y, scale, col, th=1, center=False):
    import cv2
    (tw, _), _ = cv2.getTextSize(s, cv2.FONT_HERSHEY_DUPLEX, scale, th)
    if center:
        x -= tw // 2
    cv2.putText(img, s, (int(x), int(y)), cv2.FONT_HERSHEY_DUPLEX, scale, col, th, cv2.LINE_AA)
    return img


def draw(fr, n, total, win):
    """Окно программы вокруг кадра. Интерфейс неподвижен, движется только то,
    что показывает ход работы: бегунок, полоса сборки и номер куска."""
    import numpy as np, cv2
    out = np.full((H, W, 3), BG, np.uint8)

    # шапка: имя программы, одним шрифтом и некрупно
    out = _box(out, 54, 64, W - 108, 92, PANEL, .95, 18)
    out = _text(out, NAME, W / 2, 124, .9, (226, 222, 246), 1, center=True)

    # окно с кадром: высота от оставшегося места, иначе вылезает за кадр
    y0 = int(H * .145)
    # окну отдаём всё место до дорожек: пустой верх читается как недоделка
    room = int(H * .655) - y0
    vh = min(int(W * win * 16 / 9), room)
    vw = int(vh * 9 / 16)
    vid = cv2.resize(fr, (vw, vh))
    x0 = (W - vw) // 2
    out[y0:y0 + vh, x0:x0 + vw] = vid
    # Обводка именно обводкой: заливка поверх кадра затирала картинку розовым.
    cv2.rectangle(out, (x0 - 3, y0 - 3), (x0 + vw + 2, y0 + vh + 2), EDGE, 3, cv2.LINE_AA)

    # дорожки под окном
    ty = y0 + vh + 44
    u = n / float(total)
    for r in range(3):
        yy = ty + r * 54
        out = _box(out, 60, yy, W - 120, 42, PANEL, 1.0, 10)
        for a0, a1 in ([(0, .3), (.34, .62), (.66, 1.0)],
                        [(.05, .48), (.52, .95)],
                        [(0, .55), (.6, 1.0)])[r]:
            out = _box(out, 60 + (W - 120) * a0 + 3, yy + 5, (W - 120) * (a1 - a0) - 6, 32,
                       [(255, 59, 123), (60, 255, 182), (120, 90, 230)][r], .9, 10)
        out = _text(out, ["V1", "V2", "SFX"][r], 74, yy + 29, .5, (16, 11, 24), 1)
    px = int(60 + (W - 120) * u)
    out = _box(out, px - 2, ty - 10, 4, 3 * 54 + 10, LIME, 1.0, 2)

    # полоса сборки: число настоящее, оно взято из самого ролика
    by = ty + 3 * 54 + 34
    out = _box(out, 60, by, W - 120, 22, PANEL, 1.0, 11)
    out = _box(out, 60, by, (W - 120) * u, 22, LIME, 1.0, 11)
    out = _text(out, "PIECE %d OF %d" % (1 + int(u * 9), 10), W / 2, by + 74, .64,
                (200, 194, 226), 1, center=True)

    # Панель приёмов внизу: низ не должен пустовать, а рабочее место без
    # инструментов читается как макет, а не как программа.
    fy = by + 112
    names = ["CUT", "ZOOM", "SHAKE", "GRADE", "GLOW", "TEXT"]
    bw = (W - 120 - 5 * 12) / 6.0
    act = int(u * 6) % 6
    for i, nm in enumerate(names):
        bx = 60 + i * (bw + 12)
        on = i == act
        out = _box(out, bx, fy, bw, 86, LIME if on else PANEL, 1.0, 14)
        out = _text(out, nm, bx + bw / 2, fy + 52, .52,
                    (16, 11, 24) if on else (190, 184, 214), 1, center=True)
    return out


def render(base, out, win, has_audio):
    import numpy as np, cv2
    cap = cv2.VideoCapture(base)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    pipe = ["ffmpeg", "-nostdin", "-v", "error", "-y",
            "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", "%dx%d" % (W, H),
            "-r", str(FPS), "-i", "-"]
    if has_audio:
        pipe += ["-i", base, "-map", "0:v", "-map", "1:a",
                 "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                 "-c:a", "aac", "-b:a", "256k", "-shortest"]
    pipe += ["-c:v", "libx264", "-preset", "slow", "-crf", "18",
             "-pix_fmt", "yuv420p", "-movflags", "+faststart", out]
    pr = subprocess.Popen(pipe, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                          stderr=subprocess.PIPE)
    n = 0
    while True:
        ok, fr = cap.read()
        if not ok:
            break
        if fr.shape[1] != W or fr.shape[0] != H:
            fr = cv2.resize(fr, (W, H))
        pr.stdin.write(np.ascontiguousarray(draw(fr, n, total, win), dtype=np.uint8).tobytes())
        n += 1
    cap.release()
    pr.stdin.close()
    err = pr.stderr.read().decode("utf-8", "ignore")
    pr.wait()
    if pr.returncode != 0:
        raise SystemExit(err[-800:])
    return n


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        raise SystemExit("a path to a video is required: python3 montazhka.py my-video.mp4")
    src = os.path.abspath(args[0])
    out, win = "my-montazhka.mp4", 0.86
    for i, a in enumerate(sys.argv):
        if a == "--out" and i + 1 < len(sys.argv):
            out = sys.argv[i + 1]
        if a == "--window" and i + 1 < len(sys.argv):
            win = max(.5, min(float(sys.argv[i + 1]), 1.0))
    info = probe(src)
    print("source: %.1f s, %dx%d, audio %s" %
          (info["dur"], info["w"], info["h"], "yes" if info["audio"] else "no"))
    if info["dur"] < 8:
        raise SystemExit("the clip is under eight seconds: the window has nothing to show")
    want = min(info["dur"], 30.0)
    tmp = tempfile.mkdtemp(prefix="montazh_")
    try:
        b = prepare(src, info, tmp, want)
        frames = render(b, out, win, info["audio"])
        print("done: %s, %.1f s, %.1f MB" %
              (out, frames / float(FPS), os.path.getsize(out) / 1048576.0))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
