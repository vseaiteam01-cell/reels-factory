# Editing screen

Your video inside an app window: tracks, a playhead moving through time, an
effects panel, a build queue. The genre that reads in a feed as "a
professional at work" rather than "someone put a filter on".

The second free set. One command, one result.

## What you need

- `ffmpeg` and `ffprobe`
- Python 3 with `numpy`, `opencv-python`, `pillow`
- video from eight seconds

## How to build

```bash
python3 montazhka.py my-video.mp4
```

`my-montazhka.mp4` appears next to it, vertical 1080x1920.

## Why this looks expensive

This is a breakdown of the genre, not just instructions. Four things make the
frame look expensive, and all four are cheap to do:

**1. The frame sits in a window instead of filling the screen.** There is
margin around the video, and the margin is not empty: the app's name above,
the build bar below. The eye reads that as a workplace, and a workplace
implies work.

**2. The interface is still and there is movement inside it.** The contrast
between a static frame and a live picture holds attention better than
everything moving at once. That is why the panels are not animated — only what
shows progress moves.

**3. The numbers are real.** The bar says which segment of how many is
running, and it is not decoration: the number comes from the reel itself.
Invented precision ("92 %", "4.1x") reads as fake instantly, even when the
viewer cannot say why.

**4. One font, and not a large one.** The interface does not shout. All the
text is one family, differing only in weight and opacity. Two fonts in one
window is the first sign of something homemade.

## What breaks

**The window runs off the frame** — if your source is much wider than 16:9,
the window's height is computed from the room that is left. The script does
that itself; if the frame is really unusual, make the window smaller:
`--window 0.7`.

**The reel looks static** — the source has little movement. The genre
underlines that: the window is still, and if it is quiet inside too there is
nothing to watch. Take a clip with movement in it.

## Next

This screen is one of the ten build types in the full version, where it builds
from the same command as the other nine, together with the review of nine
gates.
