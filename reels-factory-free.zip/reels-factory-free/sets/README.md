# The two free sets

Two finished tools, each with one result:

| Set | What it gives | Time on a laptop |
|---|---|---|
| [Movik](movik/) | the first movik's recipe on your video: a 42 s vertical reel with a punch-in drop, words behind the hero, money rain, mosaic with a rewind, a sticker freeze, 3D cards, colour pop, echo trails, slit-scan, shatter and captions in Anton | about 4 minutes |
| [Editor screen](screen/) | the desktop editor Reels Factory is promoted with, 2880x1800, 42 s, with your clip in the pool and the viewer and your movik in the program window | 15-30 minutes |

Run them in that order and the editor screen plays your own movik.

## Getting ready

Hand this folder to Claude or Codex with the phrase from `00 START HERE`: the
agent runs `prepare.py`, which puts Python 3.12, the libraries, ffmpeg and node
inside `sets/.venv` and asks for no password.

By hand:

```bash
uv run --no-project --python 3.12 sets/prepare.py
sets/.venv/bin/python sets/movik/movik.py "in/my-video.mp4" --title "MY TITLE" --out out/my-movik.mp4
sets/.venv/bin/python sets/screen/screen.py "in/my-video.mp4" --movik out/my-movik.mp4 --out out/my-screen.mp4
```

## What is not in them

The movik has one look, the first one; the full Reels Factory builds ten reel
types from one video, with voice, subtitles, covers and a check of every file.
No music ships with the movik: pass your own track with `--music`.

## Licences

Fonts: Anton, Archivo, Chivo, Manrope, Sofia Sans, Playfair, JetBrains Mono,
all under the SIL Open Font License. Sound effects in the screen: Kenney, CC0
(`screen/template/audio/LICENSE-kenney-CC0.txt`). The cutout model u2netp
(Apache 2.0) downloads during setup.
