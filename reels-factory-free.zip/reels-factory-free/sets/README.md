# The two free sets

Not offcuts of the paid product but finished things, each with one result you
can describe. Each installs in a minute and builds with one command.

| Set | What it gives | What it needs |
|---|---|---|
| [Build your own movik](movik/) | a beat-cut with a title card and real frame processing | video from 12 s |
| [Editing screen](montazhka/) | your video inside an app window | video from 8 s |

Both need the same things: `ffmpeg`, `ffprobe` and Python 3 with `numpy`,
`opencv-python`, `pillow`. Check them in one go:

```bash
ffmpeg -version | head -1 && python3 -c "import numpy, cv2, PIL; print('libraries in place')"
```

## Why they are free

The movik and the editing screen are two of the ten build types. They work for
real and hand you a finished file, but each one does a single thing. In the
full version those same ten types build with one command out of one clip, the
plan decides for itself which of them will come out, and a review of nine
gates keeps the junk from going out.

## Measured on our own material

A 42 s source, 540x960, with sound, on an ordinary laptop:

| Set | What came out | Length | Size | Time |
|---|---|---|---|---|
| Movik | 1080x1920, 20 segments on the cuts | 28.7 s | 35.7 MB | about 3 minutes |
| Editing screen | 1080x1920, a window with tracks and a panel | 30.0 s | 12.7 MB | about 2 minutes |

The master is written without re-compression (CRF 18) and loudness is brought
to −14 LUFS — to what the platforms expect.

## What is not in them

Not one frame and not one texture from anyone else: everything drawn over your
video is written in code and sits next to it in readable form. These two sets
need no fonts at all — the captions are drawn with the built-in OpenCV font so
the set works straight out of the archive.
