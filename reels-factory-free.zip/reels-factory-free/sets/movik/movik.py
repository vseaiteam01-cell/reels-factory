# -*- coding: utf-8 -*-
"""Build a movik from your video: the recipe of the first movik, your shots.

    python movik.py my-video.mp4 [--out my-movik.mp4] [--title "MY TITLE"]
                    [--words1 "ONE,CLIP,TEN CUTS"] [--words2 "NO EDITOR,ONE COMMAND,DONE"]
                    [--captions captions.json] [--music track.mp3] [--work folder]

Out comes a vertical 720x1280 reel, 42 seconds, the first movik's size: a punch-in drop, words sliding
behind the hero, money rain, mosaic with a rewind, a sticker freeze, 3D cards,
colour on the hero only, echo trails, slit-scan and shatter, captions in Anton.
One look, the first movik's; the full Reels Factory has ten types and more.
"""
import json, multiprocessing as mp, os, shutil, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CAPTIONS = [
    ["WATCH", "THIS ONE"], ["EVERYONE", "IS WATCHING"], ["THIS IS", "THE MOMENT"],
    ["NOBODY", "SAW IT COMING"], ["ONE CLIP", "TEN MOVES"], ["CUT", "ON THE BEAT"],
    ["WAIT", "FOR IT"], ["SAVE IT", "SEND IT"], ["DO IT", "TONIGHT"], ["FOLLOW", "FOR MORE"],
]


def arg(name, default=None):
    for i, a in enumerate(sys.argv):
        if a == name and i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return default


def three(s, fallback):
    parts = [p.strip().upper() for p in (s or "").split(",") if p.strip()]
    return (parts + fallback)[:3] if parts else fallback


def _init(work):
    os.environ["MOVIK_WORK"] = work


def _render(n):
    import recipe, cv2
    cv2.imwrite("%s/%04d.jpg" % (recipe.OUTD, n), recipe.render(n), [cv2.IMWRITE_JPEG_QUALITY, 95])
    return n


def _rewind(n):
    """Frames whose picture is read back from earlier frames (the two rewinds)."""
    import recipe
    t = n / recipe.FPS
    if t < recipe.DROP:
        return False
    k = int((t - recipe.DROP) // recipe.BARLEN + 1e-6); x = t - recipe.bar(k)
    return (k == 3 and recipe.B <= x < recipe.B + .34) or (k == 4 and x >= 2 * recipe.B)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags_with_value = {"--out", "--title", "--words1", "--words2", "--captions", "--music", "--work"}
    vals = {sys.argv[i + 1] for i, a in enumerate(sys.argv[:-1]) if a in flags_with_value}
    args = [a for a in args if a not in vals]
    if not args:
        raise SystemExit("a path to a video is required: python movik.py my-video.mp4")
    video = os.path.abspath(args[0])
    out = os.path.abspath(arg("--out", "my-movik.mp4"))
    title = (arg("--title") or os.path.splitext(os.path.basename(video))[0].replace("-", " ").replace("_", " ")).upper()
    title_words = title.split()
    words1 = three(arg("--words1"), (title_words + ["WATCH", "THIS"])[:2] + [title])
    words2 = three(arg("--words2"), ["ONE CLIP", "ONE COMMAND", "DONE"])
    caps = DEFAULT_CAPTIONS[:9] + [[title, ""]]
    if arg("--captions"):
        caps = json.load(open(arg("--captions")))
    work = arg("--work") or tempfile.mkdtemp(prefix="movik_")
    t0 = time.time()

    print("1/3 your shots and the hero", flush=True)
    sys.path.insert(0, HERE)
    import prep
    if arg("--work") and os.path.exists(os.path.join(work, "plan.json")):
        print("    shots already laid out in %s" % work, flush=True)
    else:
        prep.main(video, work)
    with open(os.path.join(work, "config.json"), "w") as f:
        json.dump({"title": title, "words1": words1, "words2": words2, "captions": caps}, f)

    print("2/3 frames: 1260 of them, the longest part", flush=True)
    os.environ["MOVIK_WORK"] = work
    import recipe
    total = int(round(42 * recipe.FPS))
    first = [n for n in range(total) if not _rewind(n)]
    second = [n for n in range(total) if _rewind(n)]
    with mp.get_context("spawn").Pool(max(1, (os.cpu_count() or 2) - 1),
                                      initializer=_init, initargs=(work,)) as pool:
        done = 0
        for _ in pool.imap_unordered(_render, first, chunksize=6):
            done += 1
            if done % 210 == 0:
                print("    %d of %d frames" % (done, total), flush=True)
        for _ in pool.imap(_render, second, chunksize=4):
            pass
    print("    %d of %d frames" % (total, total), flush=True)

    print("3/3 the reel", flush=True)
    cmd = ["ffmpeg", "-nostdin", "-v", "error", "-y", "-framerate", str(recipe.FPS),
           "-i", os.path.join(recipe.OUTD, "%04d.jpg")]
    music = arg("--music")
    if music:
        cmd += ["-i", music, "-map", "0:v", "-map", "1:a", "-shortest", "-af",
                "loudnorm=I=-14:TP=-1.5:LRA=11", "-c:a", "aac", "-b:a", "192k"]
    cmd += ["-c:v", "libx264", "-preset", "slow", "-crf", "20",
            "-pix_fmt", "yuv420p", "-movflags", "+faststart", out]
    subprocess.run(cmd, check=True)
    if not arg("--work"):
        shutil.rmtree(work, ignore_errors=True)
    size = os.path.getsize(out) / 1048576.0
    print("done: %s, 42.0 s, %.1f MB, %.1f min" % (os.path.relpath(out), size, (time.time() - t0) / 60), flush=True)


if __name__ == "__main__":
    main()
