# -*- coding: utf-8 -*-
"""Собери свой мувик: одно видео на входе, нарезка под удары на выходе.

Самодостаточный набор. Ему не нужен ни конвейер целиком, ни библиотека
эффектов: всё, что он делает с кадром, написано здесь и читается глазами.

    python3 movik.py my-video.mp4 [--out my-movik.mp4] [--no-crop]
"""
import os, sys, re, math, json, subprocess, tempfile, shutil

W, H, FPS = 1080, 1920, 30
TITLE = "TEN FROM ONE"


def run(cmd, check=True):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if check and p.returncode != 0:
        raise SystemExit((p.stderr or p.stdout)[-800:])
    return p.stdout + p.stderr


def probe(path):
    out = run(["ffprobe", "-v", "error", "-print_format", "json",
               "-show_format", "-show_streams", path])
    d = json.loads(out)
    v = next((s for s in d["streams"] if s["codec_type"] == "video"), None)
    if v is None:
        raise SystemExit("the file has no video track: " + path)
    a = next((s for s in d["streams"] if s["codec_type"] == "audio"), None)
    return {"dur": float(d["format"]["duration"]),
            "w": int(v["width"]), "h": int(v["height"]),
            "vertical": int(v["height"]) > int(v["width"]),
            "audio": a is not None}


def cuts(path):
    """Cuts: the moments where the frame changes completely."""
    out = run(["ffmpeg", "-nostdin", "-v", "info", "-i", path,
               "-vf", "select='gt(scene,0.3)',showinfo", "-an", "-f", "null", "-"], check=False)
    return sorted(set(round(float(x), 2) for x in re.findall(r"pts_time:([0-9.]+)", out)))


def hits(path, has_audio):
    """The loud spots: the edit beats stand on them."""
    if not has_audio:
        return []
    out = run(["ffmpeg", "-nostdin", "-v", "info", "-i", path,
               "-af", "ebur128=metadata=1", "-f", "null", "-"], check=False)
    mom = [(float(a), float(b)) for a, b in
           re.findall(r"t:\s*([\d.]+)\s+TARGET:.*?M:\s*(-?[\d.]+)", out, re.S)]
    if not mom:
        return []
    vals = sorted(v for _, v in mom)
    hi = vals[int(len(vals) * .88)]
    out_t, last = [], -9
    for t, v in mom:
        if v >= hi and t - last > .45:
            out_t.append(round(t, 2))
            last = t
    return out_t


def plan(info, cs, hs, target=28.0):
    """Segments: boundaries come from cuts and beats, a segment runs up to 3.2 s."""
    marks = sorted(set([0.0] + cs + hs + [info["dur"]]))
    segs, acc = [], 0.0
    for i in range(len(marks) - 1):
        if acc >= target:
            break
        a = marks[i]
        b = min(marks[i + 1], info["dur"], a + 3.2)
        if b - a < .5:
            continue
        segs.append((round(a, 2), round(b, 2)))
        acc += b - a
    return segs


def base(src, segs, tmp, crop):
    """Одним проходом: режем, склеиваем, ставим вертикаль.

    Поток читается ровно один раз, поэтому перед нарезкой стоит split:
    без него второй и следующие куски приходят пустыми.
    """
    au = probe(src)["audio"]
    vf = ("crop=ih*9/16:ih,scale=%d:%d" % (W, H)) if crop else \
         ("scale=%d:%d:force_original_aspect_ratio=decrease,"
          "pad=%d:%d:(ow-iw)/2:(oh-ih)/2" % (W, H, W, H))
    k = len(segs)
    parts = ["[0:v]split=%d%s" % (k, "".join("[sv%d]" % i for i in range(k)))]
    if au:
        parts.append("[0:a]asplit=%d%s" % (k, "".join("[sa%d]" % i for i in range(k))))
    for i, (a, b) in enumerate(segs):
        parts.append("[sv%d]trim=start=%.3f:end=%.3f,setpts=PTS-STARTPTS,%s,fps=%d[v%d]"
                     % (i, a, b, vf, FPS, i))
        if au:
            parts.append("[sa%d]atrim=start=%.3f:end=%.3f,asetpts=PTS-STARTPTS[a%d]"
                         % (i, a, b, i))
    order = "".join(("[v%d][a%d]" % (i, i)) if au else ("[v%d]" % i) for i in range(k))
    parts.append("%sconcat=n=%d:v=1:a=%d[vo]%s" % (order, k, 1 if au else 0,
                                                   "[ao]" if au else ""))
    out = os.path.join(tmp, "base.mp4")
    cmd = ["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", src,
           "-filter_complex", ";".join(parts), "-map", "[vo]"]
    if au:
        cmd += ["-map", "[ao]", "-c:a", "aac", "-b:a", "192k", "-ac", "2"]
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "16",
            "-pix_fmt", "yuv420p", out]
    run(cmd)
    return out, au


# ------------------------------------------------------------------ обработка

def _zoom(img, s, cx=.5, cy=.5):
    import cv2
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w * cx, h * cy), 0, s)
    return cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_REFLECT)


def _rgb_split(img, d):
    import numpy as np
    if d <= 0:
        return img
    out = img.copy()
    out[..., 2] = np.roll(img[..., 2], d, axis=1)
    out[..., 0] = np.roll(img[..., 0], -d, axis=1)
    return out


def _grade(img, sat=1.12, con=1.05, bri=2):
    import numpy as np, cv2
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[..., 1] = np.clip(hsv[..., 1] * sat, 0, 255)
    out = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR).astype(np.float32)
    return np.clip((out - 127.5) * con + 127.5 + bri, 0, 255).astype(np.uint8)


def _title(img, text, a):
    import numpy as np, cv2
    if a <= 0:
        return img
    h, w = img.shape[:2]
    scale = w / 620.0
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_DUPLEX, scale, 3)
    x, y = (w - tw) // 2, int(h * .30)
    pad = int(18 * scale)
    ov = img.copy()
    cv2.rectangle(ov, (x - pad, y - th - pad), (x + tw + pad, y + pad), (18, 12, 26), -1)
    img = cv2.addWeighted(ov, .72 * a, img, 1 - .72 * a, 0)
    ov = img.copy()
    cv2.putText(ov, text, (x, y), cv2.FONT_HERSHEY_DUPLEX, scale, (255, 255, 255), 3, cv2.LINE_AA)
    return cv2.addWeighted(ov, a, img, 1 - a, 0)


def render(base_path, out, hs, has_audio):
    import numpy as np, cv2
    cap = cv2.VideoCapture(base_path)
    beats = set(int(t * FPS) for t in hs)
    pipe = ["ffmpeg", "-nostdin", "-v", "error", "-y",
            "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", "%dx%d" % (W, H),
            "-r", str(FPS), "-i", "-"]
    if has_audio:
        # громкость приводится к норме площадок один раз, на мастере
        pipe += ["-i", base_path, "-map", "0:v", "-map", "1:a",
                 "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                 "-c:a", "aac", "-b:a", "256k", "-shortest"]
    # мастер не пережимается: CRF 18, preset slow
    pipe += ["-c:v", "libx264", "-preset", "slow", "-crf", "18",
             "-pix_fmt", "yuv420p", "-movflags", "+faststart", out]
    pr = subprocess.Popen(pipe, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                          stderr=subprocess.PIPE)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    n = 0
    while True:
        ok, fr = cap.read()
        if not ok:
            break
        if fr.shape[1] != W or fr.shape[0] != H:
            fr = cv2.resize(fr, (W, H))
        near = min([abs(n - b) for b in beats] or [999])
        k = max(0.0, 1 - near / 6.0)
        if k > 0:
            fr = _zoom(fr, 1 + .06 * k)
            fr = _rgb_split(fr, int(7 * k))
        u = n / float(total)
        if u < .22:
            a = min(u / .05, 1.0) * min((.22 - u) / .05, 1.0)
            fr = _title(fr, TITLE, a)
        fr = _grade(fr)
        pr.stdin.write(np.ascontiguousarray(fr, dtype=np.uint8).tobytes())
        n += 1
    cap.release()
    pr.stdin.close()
    err = pr.stderr.read().decode("utf-8", "ignore")
    pr.wait()
    if pr.returncode != 0:
        raise SystemExit(err[-800:])
    return n


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        raise SystemExit("a path to a video is required: python3 movik.py my-video.mp4")
    src = os.path.abspath(args[0])
    out = "my-movik.mp4"
    for i, a in enumerate(sys.argv):
        if a == "--out" and i + 1 < len(sys.argv):
            out = sys.argv[i + 1]
    info = probe(src)
    print("source: %.1f s, %dx%d, audio %s" %
          (info["dur"], info["w"], info["h"], "yes" if info["audio"] else "no"))
    if info["dur"] < 12:
        raise SystemExit("the clip is under twelve seconds: the edit has nothing to work with")
    cs, hs = cuts(src), hits(src, info["audio"])
    print("%d cuts, %d loud spots" % (len(cs), len(hs)))
    if not hs:
        # Без звука или с ровной дорожкой ударов не найти. Тогда ударом
        # считается сама склейка: наезд всё равно должен быть на чём-то.
        hs = cs[:]
        print("no beats in the audio, the accents go on the cuts")
    segs = plan(info, cs, hs)
    if not segs:
        raise SystemExit("not one segment was found: the material has neither cuts nor beats")
    print("segments in the edit: %d, %.1f s in all" %
          (len(segs), sum(b - a for a, b in segs)))
    tmp = tempfile.mkdtemp(prefix="movik_")
    try:
        crop = not info["vertical"] and "--no-crop" not in sys.argv
        b, au = base(src, segs, tmp, crop)
        frames = render(b, out, hs, au)
        print("done: %s, %.1f s, %.1f MB" %
              (out, frames / float(FPS), os.path.getsize(out) / 1048576.0))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
