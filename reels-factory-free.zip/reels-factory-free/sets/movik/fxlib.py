"""Библиотека эффектов мувика: настоящая обработка кадров (numpy + OpenCV), без CSS."""
import cv2, numpy as np, math, glob, os
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 720, 1280, 30
HERE = os.path.dirname(os.path.abspath(__file__))
# Планы покупателя кладёт prep.py в свою рабочую папку; шрифты лежат в наборе.
WORK = os.environ.get("MOVIK_WORK", HERE)
NF = {os.path.basename(d): len(glob.glob(d + "/*.jpg")) for d in glob.glob(WORK + "/clips/*") if not d.endswith("_m")}
YY, XX = np.mgrid[0:H, 0:W].astype(np.float32)


def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def eo(u): u = clamp(u); return 1 - (1 - u) ** 3            # ease out cubic
def ei(u): u = clamp(u); return u ** 3
def eio(u): u = clamp(u); return u * u * (3 - 2 * u)
def expo(u): u = clamp(u); return 1 - 2 ** (-10 * u) if u < 1 else 1.0
def u8(x): return np.clip(x, 0, 255).astype(np.uint8)
def _cross2(a, b):
    """z of a 2D cross product: numpy 2 refuses np.cross on 2-vectors."""
    return float(a[0] * b[1] - a[1] * b[0])


@lru_cache(maxsize=360)
def _im(p): return cv2.imread(p)
@lru_cache(maxsize=360)
def _mkraw(p):
    m = cv2.imread(p, 0)
    return cv2.GaussianBlur(m.astype(np.float32) / 255.0, (0, 0), 1.3)


SMOOTH = {d.rsplit("/", 1)[-1][:-1] for d in glob.glob(WORK + "/clips/*s") if os.path.isdir(d) and os.path.isdir(d[:-1])}
NFS = {n: len(glob.glob(WORK + "/clips/%ss/*.jpg" % n)) for n in SMOOTH}


def fr(name, t, blend=False):
    """Кадр плана в секунду t. Где есть промежуточные кадры (90 к/с), слоумо идёт по ним."""
    if name in SMOOTH:
        n = NFS[name]; x = min(max(t * 90.0, 0), n - 1); i = int(round(x))
        return _im("%s/clips/%ss/%04d.jpg" % (WORK, name, i))
    n = NF[name]; x = min(max(t * 30.0, 0), n - 1)
    i = int(x); a = x - i
    f0 = _im("%s/clips/%s/%04d.jpg" % (WORK, name, i))
    if i + 1 >= n: return f0
    if blend: return f0 if a < 0.03 else cv2.addWeighted(f0, 1 - a, _im("%s/clips/%s/%04d.jpg" % (WORK, name, i + 1)), a, 0)
    return f0 if a < .5 else _im("%s/clips/%s/%04d.jpg" % (WORK, name, i + 1))


def mt(name, t, wide=False):
    """Маска человека: между опорными кадрами идёт линейная смесь, чтобы край не прыгал."""
    sfx = "_wm" if wide else "_m"
    n = len(glob.glob("%s/clips/%s%s/*.png" % (WORK, name, sfx)))
    x = min(max(t * 30.0, 0), n - 1); i = int(x); a = x - i
    m0 = _mkraw("%s/clips/%s%s/%04d.png" % (WORK, name, sfx, i))
    if a > 0.02 and i + 1 < n:
        m0 = m0 * (1 - a) + _mkraw("%s/clips/%s%s/%04d.png" % (WORK, name, sfx, i + 1)) * a
    return m0 if m0.shape == (H, W) and not wide else m0


def frw(name, t):
    """Широкий кадр (1280x720) того же плана: человек целиком, края не режутся."""
    n = len(glob.glob("%s/clips/%s_w/*.jpg" % (WORK, name)))
    if name + "_w" in SMOOTH:
        ns = NFS[name + "_w"]; i = int(round(min(max(t * 90.0, 0), ns - 1)))
        return _im("%s/clips/%s_ws/%04d.jpg" % (WORK, name, i))
    i = int(round(min(max(t * 30.0, 0), n - 1)))
    return _im("%s/clips/%s_w/%04d.jpg" % (WORK, name, i))


def _box(x, r):
    return cv2.blur(x, (2 * r + 1, 2 * r + 1), borderType=cv2.BORDER_REFLECT)


def guided(mask, guide, r=9, eps=1e-3):
    """Guided filter: край маски прилипает к границам на картинке, контур перестаёт шуметь."""
    I = guide.astype(np.float32) / 255.0
    p = mask.astype(np.float32)
    mean_I = np.stack([_box(I[..., c], r) for c in range(3)], 2)
    mean_p = _box(p, r)
    mean_Ip = np.stack([_box(I[..., c] * p, r) for c in range(3)], 2)
    cov_Ip = mean_Ip - mean_I * mean_p[..., None]
    var = np.empty((I.shape[0], I.shape[1], 3, 3), np.float32)
    for i in range(3):
        for j in range(3):
            var[..., i, j] = _box(I[..., i] * I[..., j], r) - mean_I[..., i] * mean_I[..., j]
    var += np.eye(3, dtype=np.float32) * eps
    a_ = np.linalg.solve(var, cov_Ip[..., None]).squeeze(-1)
    b_ = mean_p - (a_ * mean_I).sum(2)
    mean_a = np.stack([_box(a_[..., c], r) for c in range(3)], 2)
    mean_b = _box(b_, r)
    return np.clip((mean_a * I).sum(2) + mean_b, 0, 1)


def clean_mask(m, guide, close=9, r=8, gain=1.25, bias=-.12):
    """Чистая вырезка: дырки закрыты, мелочь выброшена, край уточнён по картинке."""
    b = (m > .5).astype(np.uint8)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close, close))
    b = cv2.morphologyEx(cv2.morphologyEx(b, cv2.MORPH_CLOSE, k), cv2.MORPH_OPEN, k)
    nlab, lab, stats, _ = cv2.connectedComponentsWithStats(b, 8)
    if nlab > 1:
        keep = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        big = stats[keep, cv2.CC_STAT_AREA]
        b = np.isin(lab, [i for i in range(1, nlab) if stats[i, cv2.CC_STAT_AREA] > big * .08]).astype(np.uint8)
    soft = cv2.GaussianBlur(b.astype(np.float32), (0, 0), 2.2)
    g = guided(soft, guide, r)
    return np.clip((g - .5) * gain + .5 + bias, 0, 1)


def cutout(name, t, scale, cx, cy, feather=1.4):
    """Вырезанный человек как слой BGRA: берём широкий кадр, обрезаем по рамке маски,
    масштабируем так, чтобы рост занял scale высоты экрана, и ставим центром в (cx, cy)."""
    img = frw(name, t); m = mt(name, t, wide=True)
    if m.shape[:2] != img.shape[:2]: m = cv2.resize(m, (img.shape[1], img.shape[0]))
    ys, xs = np.where(m > 0.35)
    if len(ys) < 50: return None
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    pad = int(max(x1 - x0, y1 - y0) * 0.06) + 4
    x0 = max(x0 - pad, 0); y0 = max(y0 - pad, 0)
    x1 = min(x1 + pad, img.shape[1]); y1 = min(y1 + pad, img.shape[0])
    sub = img[y0:y1, x0:x1].astype(np.float32); sm = m[y0:y1, x0:x1]
    k = scale * H / (y1 - y0)
    sub = cv2.resize(sub, None, fx=k, fy=k, interpolation=cv2.INTER_LANCZOS4 if k > 1 else cv2.INTER_AREA)
    sm = cv2.resize(sm, (sub.shape[1], sub.shape[0]), interpolation=cv2.INTER_LINEAR)
    sm = clean_mask(sm, u8(sub), 9, max(4, int(6 * k)))
    sm = cv2.GaussianBlur(sm, (0, 0), feather)
    lay = np.zeros((H, W, 4), np.float32)
    lh, lw = sub.shape[:2]
    ox, oy = int(cx * W - lw / 2), int(cy * H - lh / 2)
    sx0, sy0 = max(-ox, 0), max(-oy, 0)
    dx0, dy0 = max(ox, 0), max(oy, 0)
    ww, hh = min(lw - sx0, W - dx0), min(lh - sy0, H - dy0)
    if ww <= 0 or hh <= 0: return None
    a = sm[sy0:sy0 + hh, sx0:sx0 + ww][..., None]
    lay[dy0:dy0 + hh, dx0:dx0 + ww, :3] = sub[sy0:sy0 + hh, sx0:sx0 + ww] * a
    lay[dy0:dy0 + hh, dx0:dx0 + ww, 3] = a[..., 0] * 255
    return lay


def layer_on(bg, lay, a=1.0):
    if lay is None: return bg
    al = lay[..., 3:4] / 255.0 * a
    return u8(bg.astype(np.float32) * (1 - al) + lay[..., :3] * a)


def lay_rim(lay, px=8, col=(255, 255, 255), amt=1.0):
    """Свечение по контуру вырезки."""
    if lay is None: return None
    m = lay[..., 3] / 255.0
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (px * 2 + 1, px * 2 + 1))
    r = np.clip(cv2.GaussianBlur(cv2.dilate(m, k), (0, 0), px * .7) - m, 0, 1) * amt
    out = lay.copy(); out[..., :3] += r[..., None] * np.float32(col); out[..., 3] = np.maximum(out[..., 3], r * 255)
    return out


def zoom(img, s=1.0, cx=.5, cy=.5, rot=0.0, dx=0.0, dy=0.0, border=cv2.BORDER_REFLECT):
    M = cv2.getRotationMatrix2D((cx * W, cy * H), rot, s); M[0, 2] += dx; M[1, 2] += dy
    return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=border)


def rgb_split(img, d):
    d = int(round(d))
    if d == 0: return img
    out = img.copy(); out[..., 2] = np.roll(img[..., 2], d, 1); out[..., 0] = np.roll(img[..., 0], -d, 1); return out


def zoom_blur(img, amt, n=6):
    if amt < 0.004: return img
    acc = np.zeros(img.shape, np.float32)
    for i in range(n): acc += zoom(img, 1 + amt * i / (n - 1))
    return u8(acc / n)


def rot_blur(img, deg, n=6, s=1.0):
    acc = np.zeros(img.shape, np.float32)
    for i in range(n): acc += zoom(img, s, rot=deg * i / (n - 1))
    return u8(acc / n)


def hblur(img, k):
    k = int(k)
    return img if k < 3 else cv2.blur(img, (k, 1))


def flash(img, a, col=(255, 255, 255)):
    if a <= 0.004: return img
    return cv2.addWeighted(img, 1 - min(a, 1), np.full_like(img, col), min(a, 1), 0)


def sat(img, s):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)[..., None].astype(np.float32)
    return u8(g + (img.astype(np.float32) - g) * s)


def contrast(img, c=1.0, b=0.0): return u8((img.astype(np.float32) - 127.5) * c + 127.5 + b)


def bw(img, c=1.35):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(u8((g.astype(np.float32) - 127.5) * c + 122), cv2.COLOR_GRAY2BGR)


def bloom(img, thr=175, amt=.55, sig=14):
    hi = np.clip(img.astype(np.float32) - thr, 0, 255)
    small = cv2.resize(hi, (W // 4, H // 4)); small = cv2.GaussianBlur(small, (0, 0), sig / 4)
    return u8(img + cv2.resize(small, (W, H)) * amt * 3.2)


_x = np.arange(256, dtype=np.float32)
VICE = np.stack([u8(np.interp(_x, [0, 60, 128, 200, 255], [18, 84, 138, 196, 240])),      # B: тени вверх
                 u8(np.interp(_x, [0, 60, 128, 200, 255], [4, 56, 124, 190, 236])),       # G
                 u8(np.interp(_x, [0, 60, 128, 200, 255], [0, 44, 138, 226, 255]))], 1)   # R: света в розовый
def vice(img, k=1.0):
    out = np.empty_like(img)
    for c in range(3): out[..., c] = VICE[:, c][img[..., c]]
    out = sat(out, 1.28)
    return out if k >= 1 else cv2.addWeighted(img, 1 - k, out, k, 0)


VIG = (1 - 0.34 * np.clip((((XX - W / 2) / (W * .62)) ** 2 + ((YY - H / 2) / (H * .62)) ** 2), 0, 1.6))[..., None].astype(np.float32)
def finish(img, n, punchy=True):
    f = img.astype(np.float32)
    if punchy: f = (f - 127.5) * 1.07 + 129
    f *= VIG
    rs = np.random.RandomState(n); g = rs.randint(-5, 6, (H // 2, W // 2, 1)).astype(np.float32)
    return u8(f + cv2.resize(g, (W, H), interpolation=cv2.INTER_NEAREST)[..., None])


def sub_over(bg, fg, m): return u8(bg.astype(np.float32) * (1 - m[..., None]) + fg.astype(np.float32) * m[..., None])


def rim(m, px=9):
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (px * 2 + 1, px * 2 + 1))
    d = cv2.dilate(m, k)
    return np.clip(cv2.GaussianBlur(d, (0, 0), px * .8) - m, 0, 1)


def add_col(img, a, col, gain=1.0): return u8(img.astype(np.float32) + a[..., None] * np.float32(col) * gain)


# ---------- типографика ----------
FONTS = {"anton": ("Anton-Regular.ttf", None), "wide": ("Archivo-wdth_wght.ttf", {"wdth": 125, "wght": 900}),
         "mono": ("Chivo-wght.ttf", {"wght": 700}), "bebas": ("BebasNeue-Regular.ttf", None),
         "sofia": ("SofiaSansExtraCondensed-Italic-wght.ttf", {"wght": 900}), "playfair": ("PlayfairDisplay-Italic-wght.ttf", {"wght": 600})}
_AXT = {"Width": "wdth", "Weight": "wght", "Optical size": "opsz", "Optical Size": "opsz"}
@lru_cache(maxsize=64)
def fit_size(txt, font, target_w, track=0.0, lo=20, hi=400):
    """Подобрать кегль так, чтобы строка заняла target_w пикселей."""
    while hi - lo > 1:
        mid = (lo + hi) // 2
        fn, ax = FONTS[font]; ft = ImageFont.truetype(HERE + "/assets/" + fn, mid)
        if ax:
            try:
                vals = []
                for axis in ft.get_variation_axes():
                    nm = axis["name"].decode() if isinstance(axis["name"], bytes) else axis["name"]
                    vals.append(min(max(ax.get(_AXT.get(nm, nm), axis["default"]), axis["minimum"]), axis["maximum"]))
                ft.set_variation_by_axes(vals)
            except Exception: pass
        if sum(ft.getlength(c) + track * mid for c in txt) <= target_w: lo = mid
        else: hi = mid
    return lo


def text(s, font, size, col=(255, 255, 255), stroke=0, scol=(0, 0, 0), track=0):
    fn, ax = FONTS[font]; ft = ImageFont.truetype(HERE + "/assets/" + fn, size)
    if ax:
        try:
            vals = []
            for axis in ft.get_variation_axes():
                nm = axis["name"].decode() if isinstance(axis["name"], bytes) else axis["name"]
                vals.append(min(max(ax.get(_AXT.get(nm, nm), axis["default"]), axis["minimum"]), axis["maximum"]))
            ft.set_variation_by_axes(vals)
        except Exception: pass
    pad = stroke + size // 5
    wd = sum(ft.getlength(ch) + track for ch in s)
    im = Image.new("RGBA", (int(wd + pad * 2 + size * .3), int(size * 1.35 + pad * 2)), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    x = pad
    for ch in s:
        d.text((x, pad), ch, font=ft, fill=col[::-1] + (255,), stroke_width=stroke, stroke_fill=scol[::-1] + (255,)); x += ft.getlength(ch) + track
    a = np.array(im); ys, xs = np.where(a[..., 3] > 0)
    a = a[max(ys.min() - 2, 0):ys.max() + 3, max(xs.min() - 2, 0):xs.max() + 3]
    out = a[..., [2, 1, 0, 3]].astype(np.float32); out[..., :3] *= out[..., 3:4] / 255.0   # BGR premult
    return out


def put(img, layer, cx, cy, s=1.0, rot=0.0, a=1.0, blur=0, hb=0, add=False):
    """Положить premult-слой BGRA центром в (cx, cy) пикселях."""
    lh, lw = layer.shape[:2]
    M = cv2.getRotationMatrix2D((lw / 2, lh / 2), rot, s); M[0, 2] += cx - lw / 2; M[1, 2] += cy - lh / 2
    L = cv2.warpAffine(layer, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    if blur > 0: L = cv2.GaussianBlur(L, (0, 0), blur)
    if hb >= 3: L = cv2.blur(L, (int(hb), 1))
    A = L[..., 3:4] / 255.0 * a
    if add: return u8(img.astype(np.float32) + L[..., :3] * a)
    return u8(img.astype(np.float32) * (1 - A) + L[..., :3] * a)


# ---------- 3D-деньги ----------
def _rot(ax, a):
    c, s = math.cos(a), math.sin(a)
    if ax == 0: return np.array([[1, 0, 0], [0, c, -s], [0, s, c]], np.float32)
    if ax == 1: return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]], np.float32)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], np.float32)



def _купюра(сторона):
    """Банкнота, нарисованная кодом: номинал, гильош, подпись. 600x252."""
    w, h = 600, 252
    им = np.full((h, w, 3), (206, 222, 196), np.uint8)         # BGR: бледная зелень
    rs = np.random.RandomState(7 + сторона)
    # гильош: тонкие волнистые линии по всему полю
    for i in range(46):
        y = int(h * i / 46.0)
        фаза = rs.rand() * 6.28
        точки = [(x, int(y + 7 * np.sin(x / 26.0 + фаза))) for x in range(0, w, 4)]
        cv2.polylines(им, [np.int32(точки)], False, (168, 196, 158), 1, cv2.LINE_AA)
    cv2.rectangle(им, (10, 10), (w - 11, h - 11), (96, 132, 92), 2)
    cv2.rectangle(им, (18, 18), (w - 19, h - 19), (140, 170, 132), 1)
    # овал под портретом или печать на обороте
    cv2.ellipse(им, (150 if сторона == 0 else w - 150, h // 2), (78, 96), 0, 0, 360,
                (118, 150, 112), 2, cv2.LINE_AA)
    if сторона == 0:
        cv2.ellipse(им, (150, h // 2 + 14), (46, 58), 0, 0, 360, (132, 162, 124), -1, cv2.LINE_AA)
        cv2.circle(им, (150, h // 2 - 26), 34, (142, 172, 134), -1, cv2.LINE_AA)
    шрифт = cv2.FONT_HERSHEY_DUPLEX
    # надписи уходят на свободную половину: на лице она правая, на обороте
    # левая, иначе печать наезжает на строки
    x0 = w - 258 if сторона == 0 else 44
    cv2.putText(им, "100", (x0 + 62, 84), шрифт, 2.4, (72, 104, 70), 4, cv2.LINE_AA)
    cv2.putText(им, "REELS FACTORY", (x0, 136), шрифт, 0.74, (86, 118, 84), 1, cv2.LINE_AA)
    cv2.putText(им, "ONE CLIP IN, TEN REELS OUT", (x0, 170), шрифт, 0.46,
                (104, 136, 100), 1, cv2.LINE_AA)
    cv2.putText(им, "100", (28 if сторона == 0 else w - 108, h - 28), шрифт, 1.1,
                (72, 104, 70), 2, cv2.LINE_AA)
    return им


class Bills:
    F = 1000.0; BH = 0.2104  # половина высоты купюры при ширине 1.0
    def __init__(self, n, seed, zr=(1.5, 9.0), spread=2.6, vy=0.62):
        rs = np.random.RandomState(seed)
        # Раньше здесь лежал скан настоящей банкноты. Чужой материал вынесен
        # из товара, и файлов больше нет, поэтому купюра рисуется кодом:
        # своя, непохожая на платёжное средство любой страны.
        tex = [_купюра(0), _купюра(1)]
        self.tex = [cv2.cvtColor(t, cv2.COLOR_BGR2BGRA) for t in tex]
        self.b = []
        for i in range(n):
            z = zr[0] + (zr[1] - zr[0]) * rs.rand() ** 1.25
            self.b.append(dict(z=z, x=(rs.rand() * 2 - 1) * 0.36 * z * 1.25, y=-0.64 * z - rs.rand() * spread * 1.28 * z + 0.9 * 1.28 * z * (rs.rand() < .28),
                               vy=z * (vy + .5 * rs.rand()), A=.12 * z * rs.rand(), w=1.5 + 3 * rs.rand(), ph=6.28 * rs.rand(),
                               a0=6.28 * rs.rand(), wa=(2.5 + 5 * rs.rand()) * rs.choice([-1, 1]), s0=6.28 * rs.rand(), ws=(rs.rand() - .5) * 2.4,
                               b0=6.28 * rs.rand(), wb=2 + 3 * rs.rand(), wf=3 + 4 * rs.rand(), fl=.18 + .3 * rs.rand()))
        self.b.sort(key=lambda d: -d["z"])

    def draw(self, img, t, z0, z1, focus=4.3, gain=1.0):
        out = img.astype(np.float32)
        L = np.float32([0.35, -0.55, -0.76]); L /= np.linalg.norm(L)
        for d in self.b:
            z = d["z"]
            if not (z0 <= z < z1) or t < 0: continue
            px = d["x"] + d["A"] * math.sin(d["w"] * t + d["ph"]); py = d["y"] + d["vy"] * t
            if py < -0.64 * z - 0.7 or py > 0.64 * z + 0.7: continue
            R = _rot(2, d["s0"] + d["ws"] * t) @ _rot(0, d["a0"] + d["wa"] * t) @ _rot(1, d["b0"] + .7 * math.sin(d["wb"] * t))
            fold = d["fl"] * math.sin(d["wf"] * t + d["ph"])
            sig = min(abs(z - focus) * (2.4 if z < focus else 0.9), 9.0)
            mb = int(d["vy"] / z * self.F / FPS * 0.45)
            for side in (0, 1):
                Rf = R @ _rot(1, fold if side == 0 else -fold)
                x0, x1 = (-.5, 0.0) if side == 0 else (0.0, .5)
                loc = np.float32([[x0, -self.BH, 0], [x1, -self.BH, 0], [x1, self.BH, 0], [x0, self.BH, 0]])
                if side == 0: loc[:, 0] += 0; P = (Rf @ loc.T).T
                else: P = (Rf @ loc.T).T
                P = P + np.float32([px, py, z])
                if P[:, 2].min() < 0.4: continue
                q = np.stack([self.F * P[:, 0] / P[:, 2] + W / 2, self.F * P[:, 1] / P[:, 2] + H / 2], 1).astype(np.float32)
                nrm = Rf @ np.float32([0, 0, 1]); front = float((R @ np.float32([0, 0, 1]))[2]) < 0
                T = self.tex[0 if front else 1]
                sx0, sx1 = (0, 300) if side == 0 else (300, 600)
                if not front: sx0, sx1 = 600 - sx0, 600 - sx1
                src = np.float32([[sx0, 0], [sx1, 0], [sx1, 252], [sx0, 252]])
                m = int(sig * 3 + mb + 4)
                bx0, by0 = int(math.floor(q[:, 0].min())) - m, int(math.floor(q[:, 1].min())) - m
                bx1, by1 = int(math.ceil(q[:, 0].max())) + m, int(math.ceil(q[:, 1].max())) + m
                cx0, cy0, cx1, cy1 = max(bx0, 0), max(by0, 0), min(bx1, W), min(by1, H)
                if cx1 - cx0 < 2 or cy1 - cy0 < 2 or (bx1 - bx0) > 2600: continue
                ar = 0.5 * abs(sum(q[i, 0] * q[(i + 1) % 4, 1] - q[(i + 1) % 4, 0] * q[i, 1] for i in range(4)))
                ed = [float(np.linalg.norm(q[(i + 1) % 4] - q[i])) for i in range(4)]
                if ar < 90 or ar < 0.035 * max(ed) ** 2: continue
                cr = [_cross2(q[(i + 1) % 4] - q[i], q[(i + 2) % 4] - q[(i + 1) % 4]) for i in range(4)]
                if not (all(c > 0 for c in cr) or all(c < 0 for c in cr)): continue
                Mx = cv2.getPerspectiveTransform(src, q - np.float32([cx0, cy0]))
                patch = cv2.warpPerspective(T, Mx, (cx1 - cx0, cy1 - cy0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0).astype(np.float32)
                pm = np.zeros(patch.shape[:2], np.uint8)
                cv2.fillConvexPoly(pm, np.round(q - np.float32([cx0, cy0])).astype(np.int32), 255, cv2.LINE_AA)
                patch[..., 3] = np.minimum(patch[..., 3], pm)
                sh = (0.42 + 0.72 * abs(float(nrm @ L))) * gain
                patch[..., :3] *= sh * patch[..., 3:4] / 255.0
                if mb >= 3: patch = cv2.blur(patch, (1, mb))
                if sig > 0.6: patch = cv2.GaussianBlur(patch, (0, 0), sig)
                a = patch[..., 3:4] / 255.0
                reg = out[cy0:cy1, cx0:cx1]; reg *= (1 - a); reg += patch[..., :3]
        return u8(out)


class Cards:
    """Карточки клипов в 3D: та же физика, что у купюр, текстура — кадры из планов.
    Пропорция вертикальная, у каждой белая рамка, как у полароида."""
    F = 1000.0
    def __init__(self, names, n, seed, zr=(1.6, 8.0), spread=2.4, vy=0.5, ar=16 / 9):
        rs = np.random.RandomState(seed)
        self.ar = ar; self.BH = 0.5 * ar * 0.5
        self.tex = []
        for nm in names:
            # Карточки — кадры из планов видео покупателя.
            fs = sorted(glob.glob("%s/clips/%s/*.jpg" % (WORK, nm)))
            if not fs:
                raise SystemExit("нет кадров для карточки: " + nm)
            im = cv2.imread(fs[len(fs) // 2])
            im = cv2.resize(im, (300, int(300 * ar)))
            bd = 14
            card = cv2.copyMakeBorder(im, bd, int(bd * 2.6), bd, bd, cv2.BORDER_CONSTANT, value=(242, 242, 246))
            self.tex.append(cv2.cvtColor(card, cv2.COLOR_BGR2BGRA))
        self.b = []
        for i in range(n):
            z = zr[0] + (zr[1] - zr[0]) * rs.rand() ** 1.2
            self.b.append(dict(z=z, ti=rs.randint(len(self.tex)),
                               x=(rs.rand() * 2 - 1) * 0.4 * z, y=-0.62 * z - rs.rand() * spread * z,
                               vy=z * (vy + .45 * rs.rand()), A=.1 * z * rs.rand(), w=1.4 + 2.6 * rs.rand(), ph=6.28 * rs.rand(),
                               a0=6.28 * rs.rand(), wa=(1.6 + 3.4 * rs.rand()) * rs.choice([-1, 1]),
                               s0=6.28 * rs.rand(), ws=(rs.rand() - .5) * 1.8, b0=6.28 * rs.rand(), wb=1.4 + 2.2 * rs.rand()))
        self.b.sort(key=lambda d: -d["z"])

    def draw(self, img, t, z0, z1, focus=4.0, gain=1.0):
        out = img.astype(np.float32)
        L = np.float32([0.35, -0.55, -0.76]); L /= np.linalg.norm(L)
        for d in self.b:
            z = d["z"]
            if not (z0 <= z < z1) or t < 0: continue
            px = d["x"] + d["A"] * math.sin(d["w"] * t + d["ph"]); py = d["y"] + d["vy"] * t
            if py < -0.7 * z - 1.0 or py > 0.7 * z + 1.0: continue
            R = _rot(2, d["s0"] + d["ws"] * t) @ _rot(0, d["a0"] + d["wa"] * t) @ _rot(1, d["b0"] + .6 * math.sin(d["wb"] * t))
            loc = np.float32([[-.5, -self.BH, 0], [.5, -self.BH, 0], [.5, self.BH, 0], [-.5, self.BH, 0]])
            P = (R @ loc.T).T + np.float32([px, py, z])
            if P[:, 2].min() < 0.45: continue
            q = np.stack([self.F * P[:, 0] / P[:, 2] + W / 2, self.F * P[:, 1] / P[:, 2] + H / 2], 1).astype(np.float32)
            ar_ = 0.5 * abs(sum(q[i, 0] * q[(i + 1) % 4, 1] - q[(i + 1) % 4, 0] * q[i, 1] for i in range(4)))
            ed = [float(np.linalg.norm(q[(i + 1) % 4] - q[i])) for i in range(4)]
            if ar_ < 220 or ar_ < 0.04 * max(ed) ** 2: continue
            cr = [_cross2(q[(i + 1) % 4] - q[i], q[(i + 2) % 4] - q[(i + 1) % 4]) for i in range(4)]
            if not (all(c > 0 for c in cr) or all(c < 0 for c in cr)): continue
            nrm = R @ np.float32([0, 0, 1]); front = nrm[2] < 0
            T = self.tex[d["ti"]]; th, tw = T.shape[:2]
            src = np.float32([[0, 0], [tw, 0], [tw, th], [0, th]]) if front else np.float32([[tw, 0], [0, 0], [0, th], [tw, th]])
            sig = min(abs(z - focus) * (2.2 if z < focus else 0.85), 8.0)
            mb = int(d["vy"] / z * self.F / FPS * 0.4)
            m_ = int(sig * 3 + mb + 4)
            bx0, by0 = int(q[:, 0].min()) - m_, int(q[:, 1].min()) - m_
            bx1, by1 = int(q[:, 0].max()) + m_, int(q[:, 1].max()) + m_
            cx0, cy0, cx1, cy1 = max(bx0, 0), max(by0, 0), min(bx1, W), min(by1, H)
            if cx1 - cx0 < 2 or cy1 - cy0 < 2 or (bx1 - bx0) > 2600: continue
            M = cv2.getPerspectiveTransform(src, q - np.float32([cx0, cy0]))
            patch = cv2.warpPerspective(T, M, (cx1 - cx0, cy1 - cy0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0).astype(np.float32)
            pm = np.zeros(patch.shape[:2], np.uint8)
            cv2.fillConvexPoly(pm, np.round(q - np.float32([cx0, cy0])).astype(np.int32), 255, cv2.LINE_AA)
            patch[..., 3] = np.minimum(patch[..., 3], pm)
            sh = (0.45 + 0.7 * abs(float(nrm @ L))) * gain * (1.0 if front else 0.55)
            patch[..., :3] *= sh * patch[..., 3:4] / 255.0
            if mb >= 3: patch = cv2.blur(patch, (1, mb))
            if sig > 0.6: patch = cv2.GaussianBlur(patch, (0, 0), sig)
            a = patch[..., 3:4] / 255.0
            reg = out[cy0:cy1, cx0:cx1]; reg *= (1 - a); reg += patch[..., :3]
        return u8(out)


def mosaic(img, k, bs=52):
    """Распад в мозаику: чем больше k, тем крупнее плитка."""
    if k < .02: return img
    q = max(1, int(1 + bs * k))
    small = cv2.resize(img, (max(W // q, 2), max(H // q, 2)), interpolation=cv2.INTER_AREA)
    return cv2.resize(small, (W, H), interpolation=cv2.INTER_NEAREST)


def shatter(img, u, seed=3, n=9, blow=1.0):
    """Кадр рассыпается осколками в перспективе: куски улетают и крутятся."""
    rs = np.random.RandomState(seed)
    out = np.zeros((H, W, 3), np.float32)
    gw, gh = n, int(n * H / W)
    cw, ch = W / gw, H / gh
    f = 1400.0
    for j in range(gh):
        for i in range(gw):
            x0, y0 = i * cw, j * ch
            cxp, cyp = x0 + cw / 2 - W / 2, y0 + ch / 2 - H / 2
            r = (cxp ** 2 + cyp ** 2) ** .5 / (W * .6) + .2
            d = rs.rand() * .5 + .5
            e = u * u * d * blow
            px, py, pz = cxp * (1 + 1.5 * e * r), cyp * (1 + 1.5 * e * r) + 420 * e * e, 900 * e * r * (1 + rs.rand())
            ang = (rs.rand() - .5) * 5 * e
            ca, sa = math.cos(ang), math.sin(ang)
            corners = []
            for sx, sy in ((-cw / 2, -ch / 2), (cw / 2, -ch / 2), (cw / 2, ch / 2), (-cw / 2, ch / 2)):
                rx, ry = sx * ca - sy * sa, sx * sa + sy * ca
                X, Y, Z = px + rx, py + ry, pz
                corners.append([W / 2 + f * X / (f + Z), H / 2 + f * Y / (f + Z)])
            q = np.float32(corners)
            src = np.float32([[x0, y0], [x0 + cw, y0], [x0 + cw, y0 + ch], [x0, y0 + ch]])
            bx0, by0 = max(int(q[:, 0].min()) - 2, 0), max(int(q[:, 1].min()) - 2, 0)
            bx1, by1 = min(int(q[:, 0].max()) + 2, W), min(int(q[:, 1].max()) + 2, H)
            if bx1 - bx0 < 2 or by1 - by0 < 2: continue
            M = cv2.getPerspectiveTransform(src, q - np.float32([bx0, by0]))
            patch = cv2.warpPerspective(img, M, (bx1 - bx0, by1 - by0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0).astype(np.float32)
            pm = np.zeros(patch.shape[:2], np.uint8)
            cv2.fillConvexPoly(pm, np.round(q - np.float32([bx0, by0])).astype(np.int32), 255, cv2.LINE_AA)
            sh = 1.0 - .45 * min(e * r * 1.6, 1)
            patch *= (pm[..., None] / 255.0) * sh
            reg = out[by0:by1, bx0:bx1]
            np.maximum(reg, patch, out=reg)
    return u8(out)


# ---------- взрыв ----------
_rs = np.random.RandomState(7)
def _ntex(sig):
    n = _rs.rand(512, 512).astype(np.float32); n = cv2.GaussianBlur(np.tile(n, (3, 3)), (0, 0), sig)[512:1024, 512:1024]
    return (n - n.min()) / (n.max() - n.min())
NZ = [_ntex(s) for s in (44, 18, 7, 3)]
FIRE = np.zeros((256, 3), np.float32)
for i, v in enumerate(np.linspace(0, 1, 256)):
    FIRE[i] = (np.interp(v, [0, .35, .6, .82, 1], [0, 0, 10, 120, 255]), np.interp(v, [0, .2, .45, .7, 1], [0, 8, 90, 215, 255]), np.interp(v, [0, .12, .4, .65, 1], [0, 70, 250, 255, 255]))
SPK = [(6.28 * _rs.rand(), 380 + 1500 * _rs.rand() ** 1.6, 1.6 + 1.8 * _rs.rand(), .5 + .7 * _rs.rand()) for _ in range(120)]


def _fbm(cx, cy, g, off):
    acc = np.zeros((H, W), np.float32); wsum = 0
    for k, (wt, sc) in enumerate(((.46, .55), (.28, 1.25), (.17, 2.8), (.09, 6.0))):
        mx = ((XX - cx) * sc / g + 256 + off * (k + 1) * 31) % 511; my = ((YY - cy) * sc / g + 256 - off * (k + 1) * 23) % 511
        acc += wt * cv2.remap(NZ[k], mx, my, cv2.INTER_LINEAR); wsum += wt
    return acc / wsum


def shockwave(img, cx, cy, rs_, amp, wd=70):
    r = np.sqrt((XX - cx) ** 2 + (YY - cy) ** 2) + 1e-3
    d = amp * np.exp(-((r - rs_) / wd) ** 2)
    return cv2.remap(img, XX - (XX - cx) / r * d, YY - (YY - cy) / r * d, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


def explosion(img, u, cx, cy, Rm=540.0):
    """u — секунды от детонации. Огненный шар на шуме, дым, искры, ударная волна."""
    if u < 0: return img
    img = shockwave(img, cx, cy, 60 + 1500 * u, 46 * math.exp(-3.2 * u))
    R = Rm * (1 - math.exp(-6.5 * u)) + 34
    yy = cy - 150 * u                                    # шар всплывает
    r = np.sqrt((XX - cx) ** 2 + ((YY - yy) * 1.08) ** 2)
    d = r / R
    n = _fbm(cx, yy, 0.55 + 0.9 * (1 - math.exp(-4 * u)), u)
    edge = d + 0.95 * (n - 0.5) * (0.45 + d)
    T = np.clip((1.0 - edge) / 0.5, 0, 1)
    cool = math.exp(-1.7 * u)
    heat = T ** 1.15 * np.clip(cool * 1.35 + (n - .42) * 2.6 * min(u * 2.4, 1) * cool ** .35 - 0.55 * min(u * 1.3, 1), 0, 1)
    heat = np.clip(heat * (1.0 + 0.9 * np.clip(1 - d * 1.6, 0, 1) * cool), 0, 1)
    sm = np.clip((0.86 - edge) / 0.4, 0, 1) * eio((u - .18) / .5) * np.clip(n * 1.9 - .35, 0, 1) * 0.88 * clamp((1.5 - u) / .5)
    f = img.astype(np.float32) * (1 + 0.9 * math.exp(-7 * u)) * np.float32([0.82, 0.93, 1.12]) ** min(1.0, 3 * math.exp(-4 * u))
    smc = (np.float32([16, 14, 16]) + n[..., None] * np.float32([40, 34, 38]))
    f = f * (1 - sm[..., None]) + smc * sm[..., None]
    fire = cv2.GaussianBlur(FIRE[(heat * 255).astype(np.uint8)], (0, 0), 9)
    sp = np.zeros((H, W, 3), np.float32)
    for (ang, v, kd, life) in SPK:
        if u > life * 1.5: continue
        def pos(tt):
            s_ = v * (1 - math.exp(-kd * tt)) / kd
            return cx + math.cos(ang) * s_, cy + math.sin(ang) * s_ * 0.9 + 520 * tt * tt - 60 * tt
        p0, p1 = pos(max(u - .028, 0)), pos(u); k = clamp(1 - u / (life * 1.5))
        cv2.line(sp, (int(p0[0]), int(p0[1])), (int(p1[0]), int(p1[1])), (60 * k, 170 * k, 255 * k), 2, cv2.LINE_AA)
    sp = cv2.GaussianBlur(sp, (0, 0), 1.1) * 1.6 + cv2.GaussianBlur(sp, (0, 0), 6) * 1.2
    glow = cv2.resize(cv2.GaussianBlur(cv2.resize(fire, (W // 4, H // 4)), (0, 0), 12), (W, H))
    f = f + fire * 0.55 + glow * 0.8
    # Второй слой огня: языки пламени на том же шуме, что и сам шар, только
    # мельче и поднятые вверх. Раньше здесь ключевался кадр с горящей машиной
    # из чужого клипа: у покупателя этого кадра нет, и приём падал.
    n2 = _fbm(cx, yy - 120 * u, 1.9 + 2.1 * u, u * 1.7)
    tongue = np.clip((1.0 - (d * 1.22 + 0.9 * (n2 - 0.5))) / 0.42, 0, 1)
    tongue *= np.clip((yy + R * .5 - YY) / (R * .9), 0, 1)        # пламя тянется вверх
    tongue = cv2.GaussianBlur(tongue * T, (0, 0), 3.0) * clamp((1.45 - u) / .55)
    Lf = FIRE[(np.clip(tongue * 1.35, 0, 1) * 255).astype(np.uint8)] * 1.15
    fall = np.clip(1.25 - r / (R * 1.15), 0, 1)[..., None] * clamp((1.45 - u) / .55)
    Lf = np.clip(Lf * fall * 1.2, 0, 255)
    f = np.clip(f, 0, 255); f = 255 - (255 - f) * (255 - Lf) / 255 + sp
    return u8(f)


# ---------- глитч, VHS, пиксели, 3D ----------
def glitch(img, k, seed):
    if k < .03: return img
    rs = np.random.RandomState(seed); out = img.copy()
    for _ in range(int(3 + 9 * k)):
        y = rs.randint(0, H - 20); h = rs.randint(8, int(30 + 130 * k)); dx = int((rs.rand() - .5) * 2 * 150 * k)
        band = np.roll(out[y:y + h], dx, 1)
        if rs.rand() < .45: band = rgb_split(band, int(10 + 26 * k))
        if rs.rand() < .18: band = 255 - band
        out[y:y + h] = band
    for _ in range(int(4 * k)):
        x, y = rs.randint(0, W - 160), rs.randint(0, H - 120); w, h = rs.randint(60, 160), rs.randint(30, 110)
        sx, sy = rs.randint(0, W - w), rs.randint(0, H - h); out[y:y + h, x:x + w] = img[sy:sy + h, sx:sx + w]
    out = rgb_split(out, 8 * k)
    out[::3] = u8(out[::3] * (1 - .28 * k))
    return out


def vhs(img, ph):
    dx = 26 * np.sin(YY / 37 + ph * 9) * (np.sin(YY / 190 + ph * 3.1) > .55) + 5 * np.sin(YY / 3.1 + ph * 40)
    out = cv2.remap(img, XX + dx, YY, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    out = rgb_split(out, 9); out = sat(out, .72); f = out.astype(np.float32)
    f[::2] *= .8
    for k in range(3):
        y = int((ph * (1900 + 400 * k) + 430 * k) % H); f[y:y + 10 + 8 * k] = f[y:y + 10 + 8 * k] * .35 + 190
    return u8(f * 0.94 + 10)


def pixel_dissolve(A, B, u, seed=5, bs=24):
    rs = np.random.RandomState(seed); gh, gw = H // bs + 1, W // bs
    th = .62 * rs.rand(gh, gw) + .38 * (1 - np.linspace(0, 1, gh))[:, None]      # снизу вверх
    vx = (rs.rand(gh, gw) - .5) * 520; vy = -260 - rs.rand(gh, gw) * 620
    q = max(1, int(bs * (1 - eo(u)) * 1.2))
    Bm = cv2.resize(cv2.resize(B, (W // q, H // q), interpolation=cv2.INTER_AREA), (W, H), interpolation=cv2.INTER_NEAREST) if q > 1 else B
    out = Bm.astype(np.float32) * (0.35 + 0.65 * eo(u))
    disp = np.clip(u * 1.75 - th, 0, 1)
    A32 = A.astype(np.float32)
    for moving in (False, True):
        for j in range(gh):
            for i in range(gw):
                dp = disp[j, i]
                if (dp > 0) != moving: continue
                y0, x0 = j * bs, i * bs; blk = A32[y0:y0 + bs, x0:x0 + bs]
                if blk.size == 0: continue
                if not moving: out[y0:y0 + bs, x0:x0 + bs] = blk; continue
                a = 1 - dp * 1.9
                if a <= 0: continue
                e = dp * dp; xx, yy = int(x0 + vx[j, i] * e), int(y0 + vy[j, i] * e)
                s = max(2, int(bs * (1 - .6 * dp))); bk = blk[:s, :s]
                if xx < 0 or yy < 0 or xx + bk.shape[1] > W or yy + bk.shape[0] > H: continue
                reg = out[yy:yy + bk.shape[0], xx:xx + bk.shape[1]]; reg *= (1 - a); reg += bk * a * 1.15
    return u8(out)


def _proj(pts, f=1500.0):
    return np.float32([[W / 2 + x * f / (f + z), H / 2 + y * f / (f + z)] for x, y, z in pts])
_SRC = np.float32([[0, 0], [W, 0], [W, H], [0, H]])
def persp_y(img, ang, sc=1.0, bgc=(10, 6, 14)):
    c, s = math.cos(ang), math.sin(ang); hw, hh = W / 2 * sc, H / 2 * sc
    M = cv2.getPerspectiveTransform(_SRC, _proj([(x * c, y, x * s) for x, y in ((-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh))]))
    return cv2.warpPerspective(img, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=bgc)


def flip3d(A, B, u):
    th = math.pi * eio(u); sc = 1 - .2 * math.sin(th)
    bg = u8(cv2.GaussianBlur(cv2.resize(A if th < math.pi / 2 else B, (W // 8, H // 8)), (0, 0), 6).astype(np.float32) * .25); bg = cv2.resize(bg, (W, H))
    img, a = (A, th) if th < math.pi / 2 else (B, th - math.pi)
    c, s = math.cos(a), math.sin(a); hw, hh = W / 2 * sc, H / 2 * sc
    q = _proj([(x * c, y, x * s) for x, y in ((-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh))])
    M = cv2.getPerspectiveTransform(_SRC, q)
    lay = cv2.warpPerspective(cv2.cvtColor(img, cv2.COLOR_BGR2BGRA), M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0).astype(np.float32)
    lay[..., :3] *= (0.55 + 0.45 * abs(c))
    al = lay[..., 3:4] / 255.0
    out = bg.astype(np.float32) * (1 - al) + lay[..., :3] * al
    return hblur(u8(out), 3 + 46 * abs(s) * (1 - abs(2 * u - 1)) + 1)


def cube(A, B, u):
    th = math.pi / 2 * eio(u); hw, hh = W / 2, H / 2; out = np.full((H, W, 3), (10, 6, 14), np.float32)
    faces = [(A, [(-hw, -hh, -hw), (hw, -hh, -hw), (hw, hh, -hw), (-hw, hh, -hw)], math.cos(th)),
             (B, [(hw, -hh, -hw), (hw, -hh, hw), (hw, hh, hw), (hw, hh, -hw)], math.sin(th))]
    c, s = math.cos(th), math.sin(th)
    for img, pts, lit in sorted(faces, key=lambda f: f[2]):
        rp = [(x * c + z * s, y, -x * s + z * c + hw) for x, y, z in pts]
        q = _proj(rp, 1700.0)
        if abs(q[1, 0] - q[0, 0]) < 3: continue
        M = cv2.getPerspectiveTransform(_SRC, q)
        lay = cv2.warpPerspective(cv2.cvtColor(img, cv2.COLOR_BGR2BGRA), M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0).astype(np.float32)
        al = lay[..., 3:4] / 255.0; out = out * (1 - al) + lay[..., :3] * al * (0.45 + 0.55 * lit)
    return hblur(u8(out), 2 + 34 * math.sin(math.pi * u))


def whip(A, B, u, dirn=1):
    e = eio(u); off = int(e * W)
    cat = np.hstack([A, B]) if dirn > 0 else np.hstack([B, A])
    x0 = off if dirn > 0 else W - off
    return hblur(np.ascontiguousarray(cat[:, x0:x0 + W]), 3 + 150 * math.sin(math.pi * u))


def spin(A, B, u):
    if u < .5:
        k = ei(u * 2); return rot_blur(A, 14 + 40 * k, 6, 1 + .5 * k) if k > .02 else A
    k = 1 - eo((u - .5) * 2); return flash(rot_blur(zoom(B, 1 + .5 * k, rot=-50 * k), -(8 + 40 * k), 6), .5 * k) if k > .02 else B


def stretch(img, sx):
    M = np.float32([[sx, 0, W / 2 * (1 - sx)], [0, 1 / math.sqrt(max(sx, .3)), H / 2 * (1 - 1 / math.sqrt(max(sx, .3)))]])
    return hblur(cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT), abs(sx - 1) * 60)


def heat(img, t, amp=5):
    return cv2.remap(img, XX + amp * np.sin(YY / 17 + t * 26), YY + amp * .6 * np.sin(XX / 23 + t * 19), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
