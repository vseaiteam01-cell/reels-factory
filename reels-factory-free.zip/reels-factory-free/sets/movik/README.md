# Build your own movik

You bring your own video and get a beat-cut back: the cuts on the loud spots,
a push in on the beat, colour channels offset, a title card at the start. The
genre people usually assemble by hand in half a day.

This is a finished thing, not an offcut. One result, one command, no settings.

## What you need

- `ffmpeg` and `ffprobe` on the system
- Python 3 with `numpy`, `opencv-python`, `pillow`
- the video itself: twelve seconds and up, with any sound

To check it is all there:

```bash
ffmpeg -version | head -1 && python3 -c "import numpy, cv2, PIL; print('libraries in place')"
```

## How to build

```bash
python3 movik.py my-video.mp4
```

`my-movik.mp4` appears next to it — a vertical 1080x1920 reel, ready to post.

## What happens inside

1. **Analysis.** `ffmpeg` looks for cuts in the picture and loud spots in the
   audio. That is the grid the edit lies on: the reel is cut where the
   material itself changes, not into equal pieces.
2. **Cutting.** The segments are taken out in one pass and joined into a
   vertical frame.
3. **Processing.** Every frame goes through real frame-by-frame work: a push
   in and a colour-channel offset on the beat, with colour and contrast lifted
   across the whole reel.
4. **Output.** The master is written without re-compression: CRF 18, audio
   brought to −14 LUFS, as the platforms expect.

## How long it takes

Forty seconds of source is about three minutes on an ordinary laptop. The last
step takes the longest: every frame is actually processed, not covered with a
filter.

## What breaks

**"the file has no video track"** — the file turned out to be audio or a
broken container. Check with `ffprobe my-video.mp4`.

**The reel came out shorter than expected** — the source has few cuts and the
edit has nothing to lean on. Take a livelier or longer clip.

**Black bars at the sides** — the source is already vertical and needs no
crop. The script works that out itself, but if the frame is unusual, say so:
`python3 movik.py my-video.mp4 --no-crop`.

## Next

This movik is one of the ten build types in the full version. The other nine:
talking head, head with effects, voice-over, point by point, before and after,
top 5, reaction, editing screen, hook loop. The full version also has the
review of nine gates that keeps the junk from going out.
