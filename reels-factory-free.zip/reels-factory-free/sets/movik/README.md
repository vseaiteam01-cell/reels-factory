# Movik

The recipe of the first movik, the one cut from the GTA 6 trailer, on your own
video. One look, fifteen bars, 42 seconds, 720x1280.

```bash
python movik.py my-video.mp4 --title "MY TITLE" --out my-movik.mp4
```

Options:

| Flag | What it sets | Default |
|---|---|---|
| `--title` | the big title at the end, in Anton | the file name |
| `--words1` | three words that slide behind the hero in bar 1, comma separated | two title words and the title |
| `--words2` | three words behind the hero in bar 8 | ONE CLIP, ONE COMMAND, DONE |
| `--captions` | a JSON list of ten `[line1, line2]` captions | ten neutral lines |
| `--music` | a track laid under the reel | no sound |

## What happens

1. `prep.py` finds the shot changes and, with the small u2netp model, the
   person in each shot. The six moments that cut the hero out go to the shots
   where the person is largest; the rest follow your video in order.
2. `recipe.py` renders 1260 frames: the first movik's grid at 105 bpm, its
   effects (`fxlib.py`, real frame processing with numpy and OpenCV) and its
   lettering in Anton and Archivo, white and lime.
3. The frames become one H.264 file.

A video of 20 seconds or more with a person in it gives the best result; the
cutout works on anything with a clear subject.
