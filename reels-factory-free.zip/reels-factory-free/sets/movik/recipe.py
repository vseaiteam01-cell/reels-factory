"""The recipe of the first movik: 42 s, 720x1280, 30 fps, fifteen bars.

The same grid, effects and lettering as the first movik cut from the GTA 6
trailer; the shots come from your video (prep.py), the title and the words
from movik.py. Grid: 105.26 bpm, a beat B = 0.57 s, a bar 2.28 s, the drop at
4.2 s, a break 29.28-31.56 s, the second drop at 31.56 s.
"""
import sys, os, math, cv2, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fxlib import *

B, DROP, BARLEN = 0.57, 4.2, 2.28
def bar(k): return DROP + BARLEN * k
OUTD = WORK + "/out"; os.makedirs(OUTD, exist_ok=True)
import json as _json
CFG = _json.load(open(WORK + "/config.json"))
PINK, GOLD, LIME, CYAN = (149, 45, 255), (90, 214, 255), (78, 255, 188), (255, 232, 53)
CAP_FONT = "anton"


def _logo():
    """Your title in place of the trailer logo: Anton, white, two lines if long."""
    words = CFG["title"].split()
    if len(CFG["title"]) > 12 and len(words) > 1:
        h = (len(words) + 1) // 2
        a, b = text(" ".join(words[:h]), CAP_FONT, fit_size(" ".join(words[:h]), CAP_FONT, W * .86)), \
            text(" ".join(words[h:]), CAP_FONT, fit_size(" ".join(words[h:]), CAP_FONT, W * .86), LIME)
        out = np.zeros((a.shape[0] + b.shape[0] + 10, max(a.shape[1], b.shape[1]), 4), np.float32)
        out[:a.shape[0], (out.shape[1] - a.shape[1]) // 2:(out.shape[1] - a.shape[1]) // 2 + a.shape[1]] = a
        out[a.shape[0] + 10:, (out.shape[1] - b.shape[1]) // 2:(out.shape[1] - b.shape[1]) // 2 + b.shape[1]] = b
        return out
    return text(CFG["title"], CAP_FONT, fit_size(CFG["title"], CAP_FONT, W * .86))


LOGO = _logo()
RAIN1 = Bills(52, 11); RAIN2 = Bills(64, 23, spread=3.6); RAIN3 = Bills(40, 37, spread=1.4)
CARDS = Cards(["highway", "club", "jetski", "drift", "kitchen", "gym", "selfie", "redcar", "lowrider", "cop"], 46, 5)
CARDS2 = Cards(["moto", "boat", "truckman", "skyline", "roof"], 26, 19, spread=1.6)


def old(n): return cv2.imread("%s/%04d.jpg" % (OUTD, max(n, 0)))


_FROZEN = {}


def frozen(name, ts, scale, cx, cy):
    """Вырезка стоп-кадром: маска считается один раз, поэтому контур не шумит."""
    key = (name, round(ts, 3), round(scale, 3), round(cx, 3), round(cy, 3))
    if key not in _FROZEN:
        _FROZEN[key] = cutout(name, ts, scale, cx, cy)
    return _FROZEN[key]


def slide(img, lay, text_lay, u, y, hold=.52, run=.3, behind=True):
    """Слово заезжает за героя, стоит, уезжает: движение даёт текст, а не маска."""
    if u < 0: return img
    if u < run: e = expo(u / run); x = W * 1.42 - (W * 1.42 - W * .5) * e; hb = (1 - e) * 150
    elif u < run + hold: x, hb = W * .5, 0
    elif u < run * 2 + hold: e = ei((u - run - hold) / run); x = W * .5 - (W * 1.42) * e; hb = e * 150
    else: return img
    out = put(img, text_lay, x, y, hb=hb)
    return layer_on(out, lay) if behind else out


def big(txt, w=0.86, font=None, col=(255, 255, 255)):
    """Строка во всю ширину: только буквы, без обводки и тени."""
    font = font or CAP_FONT
    return text(txt, font, fit_size(txt, font, W * w), col)


def chip(txt, col=(255, 255, 255)):
    """Мелкая плашка слоя, как в монтажке."""
    lay = text(txt, "mono", 30, col, track=2)
    pad = 14
    out = np.zeros((lay.shape[0] + pad * 2, lay.shape[1] + pad * 2, 4), np.float32)
    out[..., :3] = np.float32([14, 10, 18]) * .92; out[..., 3] = 214
    out[pad:pad + lay.shape[0], pad:pad + lay.shape[1]] = np.maximum(out[pad:pad + lay.shape[0], pad:pad + lay.shape[1]], lay)
    out[:2], out[-2:], out[:, :2], out[:, -2:] = [np.float32(list(col) + [255])] * 4
    return out


def fxbox(img, u, label, col=LIME, fade=.18):
    """Слой эффекта влетел: тонкая рамка по кадру и его имя. Живёт меньше удара."""
    if u < 0 or u > .7: return img
    a = clamp(u / .07) * clamp((.7 - u) / fade)
    out = img.copy()
    th = 3
    k = 1 - .04 * (1 - clamp(u / .12))
    x0, y0 = int(W * (1 - k) / 2), int(H * (1 - k) / 2)
    ov = out.astype(np.float32)
    cv2.rectangle(ov, (x0, y0), (W - x0, H - y0), tuple(float(c) for c in col), th)
    for cx, cy in ((x0, y0), (W - x0, y0), (x0, H - y0), (W - x0, H - y0)):
        cv2.rectangle(ov, (cx - 14, cy - 14), (cx + 14, cy + 14), tuple(float(c) for c in col), th)
    out = u8(out.astype(np.float32) * (1 - a) + ov * a)
    return put(out, chip(label, col), W * .5, y0 + 46, a=a)


def seg(t):
    """Возвращает (кадр, пульс_разрешён)."""
    # ---------- до дропа: сырьё, скорость 1.0 ----------
    if t < 2.49:
        name, x, off = ("highway", t, 0.1) if t < 1.35 else ("roof", t - 1.35, 0.25)
        return contrast(sat(zoom(fr(name, off + x), 1 + .035 * x), .74), .92, 5), False
    if t < DROP:
        x = t - 2.49; img = fr("jason", 0.1 + x * 0.55)
        st = 1.0 + (0.07 if t >= 3.06 else 0) + (0.09 if t >= 3.63 else 0)
        img = zoom(img, (1 + .05 * x) * st, .5, .32)
        k = eio(x / 1.71); img = contrast(sat(img, .74 - .6 * k), .92 + .25 * k, 5 - 40 * k)
        for hh in (3.06, 3.63):
            if 0 <= t - hh < .07: img = flash(rgb_split(img, 8), .22)
        return img, False

    k = int((t - DROP) // BARLEN + 1e-6); x = t - bar(k)

    # ---------- 0 : PUNCH ZOOM ----------
    if k == 0:
        if x < B:
            ts = .99 + min(x, .2) * 2.0 + max(x - .2, 0) * .8
            img = fr("jason", ts); amp = 20 * math.exp(-7 * x)
            img = zoom(img, 1 + .5 * math.exp(-10 * x), .5, .30, rot=1.6 * math.exp(-8 * x) * math.sin(44 * x),
                       dx=amp * math.sin(47 * x + 1.3), dy=amp * math.cos(61 * x))
            img = bloom(sat(zoom_blur(img, .14 * math.exp(-11 * x)), 1.18), 205, .28)
            return flash(rgb_split(img, 16 * math.exp(-9 * x)), .9 * math.exp(-24 * x)), True
        if x < 2 * B:
            y = x - B; bgi = sat(fr("kitchen", .15 + y), 1.2)
            if y < .13: return whip(sat(fr("jason", 1.5), 1.22), bgi, y / .13), False
            return bloom(bgi, 180, .4), True
        y = x - 2 * B; st = int(y / .19); yl = y - st * .19
        img = zoom(fr("selfie", .1 + y), (1.0, 1.2, 1.44, 1.7)[min(st, 3)] + .06 * math.exp(-30 * yl), .42, .46)
        return flash(rgb_split(sat(img, 1.25), 10 * math.exp(-25 * yl)), .3 * math.exp(-30 * yl)), False

    # ---------- 1 : стоп-кадр, слова заезжают за героиню, фон рассыпается ----------
    if k == 1:
        lay = frozen("lucia_prison", 0.95, 0.80, .5, .57)
        if x < 2 * B:
            bgi = darkplate(x)
            bgi = slide(bgi, lay, big(CFG["words1"][0], .80, "wide", PINK), x - .02, H * .215)
            bgi = slide(bgi, lay, big(CFG["words1"][1], .52, "wide", GOLD), x - .60, H * .33)
            out = slide(bgi, lay, big(CFG["words1"][2], .72, "wide", (255, 255, 255)), x - 1.0, H * .26)
            if x < .04: out = layer_on(out, lay)
            out = fxbox(out, x - .02, "BG REMOVE", (255, 120, 255))
            return flash(rgb_split(out, 10 * math.exp(-11 * x)), .8 * math.exp(-22 * x)), True
        y = x - 2 * B
        live = vice(zoom(fr("skyline", 1.9 + y * .08), 1.12 + .05 * y, .5, .5), .6)
        bgi = pixel_dissolve(darkplate(2 * B + y), contrast(live, 1.05, -40), clamp(y / .42), 9, 26)
        out = layer_on(bgi, lay)
        if y > .42: out = u8(out.astype(np.float32) * (1 - clamp((y - .42) / .2)) + bloom(contrast(live, 1.0, 6), 180, .4).astype(np.float32) * clamp((y - .42) / .2))
        return flash(out, .7 * math.exp(-18 * y), (220, 170, 255)), True

    # ---------- 2 : MONEY RAIN ----------
    if k == 2:
        ts = x * .7; f = fr("jl_car", ts); m = mt("jl_car", ts)
        s = 1.0 + .16 * math.exp(-9 * x) + .03 * x
        f = zoom(sat(f, 1.15), s, .5, .45); m = zoom(m, s, .5, .45)
        bgi = RAIN1.draw(f, x + .25, 4.6, 99)
        out = RAIN1.draw(sub_over(bgi, f, m), x + .25, 0, 4.6)
        out = fxbox(out, x - .02, "MONEY RAIN", (120, 235, 255))
        return flash(bloom(out, 185, .4), .7 * math.exp(-20 * x), (150, 235, 255)), True

    # ---------- 3 : эффект наложили, перемотали назад, наложили другой ----------
    if k == 3:
        if x < B:                                           # мозаика нарастает и спадает
            img = sat(fr("club", .3 + x), 1.25)
            kk = math.exp(-4.5 * x) * (1 - clamp((x - .34) / .18))
            out = mosaic(img, kk * .9)
            out = glitch(out, kk * .5, int(t * 30))
            return fxbox(out, x - .02, "MOSAIC", (120, 235, 255)), True
        if x < B + .34:                                     # вжик назад, слой снимается
            y = x - B
            n0 = int(round(bar(3) * 30)); n1 = int(round((bar(3) + B) * 30)) - 1
            return vhs(old(int(n1 - (n1 - n0) * eio(y / .34))), t), False
        y = x - B - .34
        img = vice(fr("cop", .2 + y), .7)
        kk = math.exp(-6 * y)
        out = flash(glitch(zoom(img, 1.08 + .16 * kk, .5, .35), kk * .85, int(t * 30)), .35 * kk, CYAN)
        return fxbox(out, y - .02, "GLITCH RGB", (255, 232, 53)), True

    # ---------- 4 : стоп-кадр наклейкой и перемотка ----------
    if k == 4:
        if x < 2 * B:
            if x < .22: return sat(fr("moto", x), 1.2), True
            y = x - .22
            lay = frozen("moto", .22, 0.72, .5, .55)
            bgi = u8(cv2.GaussianBlur(bw(sat(fr("moto", .22), 1.2), 1.15), (0, 0), 7).astype(np.float32) * .5)
            if lay is not None:
                m = lay[..., 3] / 255.0
                ol = cv2.GaussianBlur(cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (29, 29))), (0, 0), 1.6)
                sh = cv2.GaussianBlur(np.roll(np.roll(ol, 20, 0), 12, 1), (0, 0), 14)
                bgi = u8(bgi.astype(np.float32) * (1 - .7 * sh[..., None]))
                bgi = sub_over(bgi, np.full_like(bgi, 255), np.clip(ol, 0, 1))
            out = layer_on(bgi, lay)
            out = fxbox(out, y - .02, "STICKER CUT", (255, 255, 255))
            return flash(out, .9 * math.exp(-16 * y)), False
        y = x - 2 * B
        n1 = int(round((bar(4) + 2 * B) * 30)) - 1; n0 = int(round(bar(1) * 30))
        return vhs(old(int(n1 - (n1 - n0) * eio(y / (2 * B)))), t), False

    # ---------- 5 : CARD STORM — карточки клипов в 3D ----------
    if k == 5:
        ts = .1 + x * .8
        f = sat(fr("dance", .4 + ts * .9), 1.15)
        f = zoom(f, 1.06 + .12 * math.exp(-8 * x), .5, .45)
        bgi = CARDS.draw(u8(f.astype(np.float32) * .82), x + .2, 3.6, 99)
        out = CARDS.draw(bgi, x + .2, 0, 3.6)
        out = fxbox(out, x - .02, "CLIP CARDS", (120, 235, 255))
        return flash(bloom(out, 190, .35), .7 * math.exp(-18 * x), (200, 220, 255)), True

    # ---------- 6 : цвет только на герое, стоп-кадром; шторка LUT ----------
    if k == 6:
        TS = .34
        lay = frozen("lucia_car", TS, 0.86, .5, .56)
        base = fr("lucia_car", TS)
        grey = u8(bw(zoom(base, 1.04, .5, .4), 1.45).astype(np.float32) * .78)
        pop = layer_on(grey, lay)
        if x < 2 * B:
            out = fxbox(pop, x - .02, "COLOR POP", (255, 120, 255))
            return flash(out, .9 * math.exp(-22 * x)), True
        y = x - 2 * B
        g = bloom(vice(sat(zoom(base, 1.04, .5, .4), 1.15)), 165, .6)
        xw = -360 + 1500 * eio(y / .38); d = XX + (YY - H / 2) * .28 - xw
        out = np.where((d < 0)[..., None], g, pop)
        out = add_col(out, np.exp(-(d / 7) ** 2) * (y < .38), (255, 210, 255), 1.3)
        if y > .62:
            yy = clamp((y - .62) / .34)
            out = pixel_dissolve(out, sat(fr("lucia_car", TS + (y - .62) * 1.0), 1.2), yy, 11, 22)
        return fxbox(out, y - .02, "NEON LUT", (255, 232, 53)), True

    # ---------- 7 : ECHO TRAIL ----------
    if k == 7:
        if x < 1.75:
            ts = .06 + x * .62; f = fr("yellow", ts); m = mt("yellow", ts)
            out = u8(cv2.GaussianBlur(bw(f, 1.15), (0, 0), 2.5).astype(np.float32) * .46).astype(np.float32)
            for j, (lag, col) in enumerate(((.42, (255, 80, 60)), (.3, PINK), (.19, (255, 200, 60)), (.09, (140, 90, 255)))):
                tl = ts - lag * (0.6 + .4 * min(x * 2, 1)); kk = 1 + .035 * (4 - j); off = -26 * (4 - j)
                fe = zoom(fr("yellow", tl), kk, .5, .5, dx=off)
                me = zoom(mt("yellow", tl), kk, .5, .5, dx=off, border=cv2.BORDER_CONSTANT)
                g = cv2.cvtColor(fe, cv2.COLOR_BGR2GRAY).astype(np.float32)[..., None] / 255.0
                out += me[..., None] * (.25 + g) * np.float32(col) * (.5 + .13 * j)
            out = sub_over(u8(out), sat(f, 1.35), m)
            out = fxbox(out, x - .02, "ECHO TRAIL", (255, 120, 255))
            return flash(zoom(out, 1.02 + .14 * math.exp(-9 * x)), .85 * math.exp(-20 * x), (255, 200, 240)), True
        return spin(sat(fr("yellow", 1.15), 1.3), _phone(0.0), (x - 1.75) / .53), False

    # ---------- 8 : TEXT BEHIND ----------
    if k == 8: return _phone(x), True

    # ---------- 9 : FLIP 3D и куб ----------
    if k == 9:
        if x < .42: return flip3d(_phone(2.28), sat(fr("jetski", 0), 1.2), x / .42), False
        if x < 2 * B: return bloom(sat(fr("jetski", (x - .42) * 1.1), 1.2), 190, .4), True
        y = x - 2 * B; bgi = vice(fr("drift", y * .8), .6)
        if y < .4: return cube(sat(fr("jetski", .8), 1.2), bgi, y / .4), False
        return bgi, True

    # ---------- 10 : растяжение, slit-scan, осколки ----------
    if k == 10:
        if x < B + .28:
            ts = x * .5; f = np.empty((H, W, 3), np.uint8); n = 18; sw = W // n
            for i in range(n): f[:, i * sw:(i + 1) * sw] = fr("redcar", ts - .14 * math.exp(-2 * x) * i / n)[:, i * sw:(i + 1) * sw]
            f = stretch(sat(f, 1.3), 1 + .85 * math.exp(-6 * x) * math.cos(17 * x))
            out = flash(rgb_split(f, 18 * math.exp(-6 * x)), .7 * math.exp(-20 * x), (200, 255, 200))
            return fxbox(out, x - .02, "SLIT SCAN", (120, 235, 255)), True
        y = x - B - .28
        bgi = sat(fr("boat", y * .66), 1.25)
        if y < .14: return whip(sat(fr("redcar", .5), 1.3), bgi, y / .14, -1), False
        yy = y - .14
        if yy > .55:                                        # кадр рассыпается осколками
            u = (yy - .55) / .5
            out = shatter(bloom(bgi, 170, .4), u, 7, 9, 1.0)
            return fxbox(out, (yy - .55) - .02, "SHATTER", (255, 255, 255)), False
        return bloom(bgi, 170, .5), True

    # ---------- 11 : брейк трека, напряжение ----------
    if k == 11:
        img = fr("club", .2 + x * .36)
        st = 1.0 + (0.07 if x >= 1.14 else 0) + (0.1 if x >= 1.71 else 0)
        kk = eio(x / 2.28)
        img = contrast(sat(zoom(img, (1 + .06 * x) * st, .5, .4), 1.1 - .95 * kk), 1 + .2 * kk, -46 * kk)
        for hh in (1.14, 1.71):
            if 0 <= x - hh < .07: img = flash(rgb_split(img, 8), .22)
        return img, False

    # ---------- 12 : второй дроп, восемь планов по пол-удара ----------
    if k == 12:
        names = (("gym", .5), ("drift", .3), ("kitchen", .2), ("selfie", .3), ("club", 1.2), ("roof", .9), ("moto", .8), ("jason", .7))
        j = min(int(x / .285), 7); xl = x - j * .285; nm, off = names[j]
        f = sat(fr(nm, off + xl * 1.3), 1.28)
        f = zoom_blur(zoom(f, 1 + .42 * math.exp(-13 * xl), .5, .36), .16 * math.exp(-15 * xl))
        if j % 3 == 2: f = vice(f)
        return flash(rgb_split(f, 12 * math.exp(-14 * xl)), .45 * math.exp(-24 * xl)), False

    # ---------- 13 : тряска и строб ----------
    if k == 13:
        name, y, sp, off = ("truckman", x, 1.2, 1.9) if x < 2 * B else ("lowrider", x - 2 * B, 1.3, .2)
        tb = y % B; amp = 26 * math.exp(-5 * tb)
        f = sat(fr(name, off + y * sp), 1.3)
        f = zoom(f, 1.08 + .12 * math.exp(-8 * tb), rot=1.4 * math.sin(55 * y) * math.exp(-5 * tb),
                 dx=amp * math.sin(51 * y), dy=amp * math.cos(73 * y))
        if tb < .09: f = contrast(bw(f, 1.15), 1.0, 22)
        elif tb < .18: f = vice(f)
        return rgb_split(zoom_blur(f, .1 * math.exp(-9 * tb)), 14 * math.exp(-7 * tb)), False

    # ---------- 14 и дальше : логотип, деньги и карточки ----------
    x = t - bar(14)
    bgi = bloom(vice(zoom(fr("skyline", 1.86 + x * .02), 1.1 + .012 * x, .5, .52), .55), 160, .6)
    bgi = RAIN2.draw(bgi, x + .2, 5.0, 99, gain=1.05)
    bgi = CARDS2.draw(bgi, x - .1, 4.4, 99, gain=.95)
    h2, h3 = x - BARLEN, x - 2 * BARLEN
    s = 1 + 1.9 * math.exp(-11 * x) + (.14 * math.exp(-9 * h2) if h2 >= 0 else 0) + (.07 * math.exp(-9 * h3) if h3 >= 0 else 0)
    out = put(bgi, LOGO, W / 2, H * .36, s=s * .86, rot=-2.0 * math.exp(-8 * x))
    out = RAIN2.draw(out, x + .2, 0, 5.0)
    out = CARDS2.draw(out, x - .1, 0, 4.4)
    if h2 >= 0: out = RAIN3.draw(out, h2 + .1, 0, 99)
    if h3 >= 0: out = RAIN1.draw(out, h3 + .1, 0, 99)
    fl = .95 * math.exp(-18 * x) + (.55 * math.exp(-18 * h2) if h2 >= 0 else 0) + (.3 * math.exp(-18 * h3) if h3 >= 0 else 0)
    return flash(rgb_split(out, 16 * math.exp(-9 * x)), fl, (235, 215, 255)), False


def darkplate(x):
    r = np.sqrt(((XX - W * .5) / W) ** 2 + ((YY - H * .48) / H) ** 2)
    g = np.clip(1 - r * 1.9, 0, 1) ** 2
    f = np.float32([20, 6, 14]) + g[..., None] * np.float32([120, 20, 150]) * (0.75 + 0.25 * math.sin(x * 5))
    sw = np.exp(-((XX * .8 + YY * .5 - (x * 1500 % 2200)) / 60) ** 2)[..., None]
    return u8(f + sw * np.float32([70, 40, 90]))


def _phone(x):
    """Слова за героем: герой вырезан стоп-кадром, движется только текст."""
    TS = 1.35
    lay = frozen("phone", TS, 0.74, .5, .60)
    if lay is not None:
        lay = lay.copy(); lay[..., :3] = np.clip(lay[..., :3] * 1.22, 0, 255)
    bgi = u8(cv2.GaussianBlur(vice(fr("phone", TS)), (0, 0), 12).astype(np.float32) * .46)
    out = slide(bgi, lay, big(CFG["words2"][0], .78, "wide", (255, 255, 255)), x - .02, H * .19)
    out = slide(out, lay, big(CFG["words2"][1], .80, "wide", LIME), x - .5, H * .33)
    out = slide(out, lay, big(CFG["words2"][2], .52, "wide", GOLD), x - 1.16, H * .25)
    if x < .04: out = layer_on(out, lay)
    out = fxbox(out, x - .02, "TEXT BEHIND", (78, 255, 188))
    return flash(rgb_split(out, 10 * math.exp(-10 * x)), .75 * math.exp(-20 * x))


# ---------- субтитры: только латиница, только буквы ----------
# Captions: the timing of the first movik, the words from config.json.
_AT = [4.2, 6.48, 8.76, 11.04, 15.60, 17.88, 20.16, 22.44, 27.00, 36.12]
CAPS = []
for _i, _c in enumerate(CFG["captions"][:len(_AT)]):
    _row = (_c[0], _c[1] if len(_c) > 1 else "", _AT[_i])
    CAPS.append(_row + ("type",) if _i == 3 else _row)


TYPE_STEPS = [1, .72, 1.24, .86, 1.1, .64, 1.3, .92]


def typed(txt, u, cps=26):
    """Сколько букв набрано к моменту u и где стоит каретка."""
    t = 0.0
    for i, ch in enumerate(txt):
        step = (1 / cps) * TYPE_STEPS[i % len(TYPE_STEPS)] * (1.8 if ch == " " else 1)
        if u < t + step: return i, t
        t += step
    return len(txt), t


def caret(img, x, y, h, u, col=(255, 255, 255)):
    """Мигающая каретка: 0.28 с горит, 0.28 с гаснет."""
    if (u % 0.56) > 0.3: return img
    x0, y0 = int(x), int(y)
    out = img.astype(np.float32)
    out[max(y0 - h // 2, 0):y0 + h // 2, max(x0, 0):x0 + 5] = np.float32(col)
    return u8(out)


def captions(img, t):
    for i, cap in enumerate(CAPS):
        l1, l2, at = cap[0], cap[1], cap[2]
        mode = cap[3] if len(cap) > 3 else ""
        span = 2.0 if l2 else 2.6
        u = t - at
        if not (0 <= u < span): continue
        a1 = clamp(u / .07) * clamp((span - u) / .14)
        L1 = big(l1, .84)
        step = L1.shape[0] * 1.14
        y = H * .74 - (step / 2 if l2 else 0)
        if mode == "type":
            # субтитр набирают прямо на кадре: буквы приходят по одной, каретка мигает
            n1, dur1 = typed(l1, u)
            part = l1[:n1]
            if part:
                P = text(part, CAP_FONT, fit_size(l1, CAP_FONT, W * .84), (255, 255, 255))
                img = put(img, P, W * .5 - (L1.shape[1] - P.shape[1]) / 2, y, a=a1)
                cx = W * .5 - (L1.shape[1] - P.shape[1]) / 2 + P.shape[1] / 2 + 14
            else:
                cx = W * .5 - L1.shape[1] / 2 + 14
            if n1 < len(l1):
                img = caret(img, cx, y, int(L1.shape[0] * .78), u)
                continue
            u2 = u - dur1 - .14
            if u2 > 0 and l2:
                L2 = big(l2, .84, col=LIME)
                n2, dur2 = typed(l2, u2)
                p2 = l2[:n2]
                if p2:
                    P2 = text(p2, CAP_FONT, fit_size(l2, CAP_FONT, W * .84), LIME)
                    img = put(img, P2, W * .5 - (L2.shape[1] - P2.shape[1]) / 2, y + step, a=a1)
                    c2 = W * .5 - (L2.shape[1] - P2.shape[1]) / 2 + P2.shape[1] / 2 + 14
                else:
                    c2 = W * .5 - L2.shape[1] / 2 + 14
                if n2 < len(l2):
                    img = caret(img, c2, y + step, int(L2.shape[0] * .78), u2, LIME)
            continue
        img = put(img, L1, W * .5, y, s=1 + .10 * math.exp(-16 * u), a=a1)
        if l2:
            u2 = u - .12
            if u2 > 0:
                img = put(img, big(l2, .84, col=LIME), W * .5, y + step, s=1 + .10 * math.exp(-16 * u2), a=clamp(u2 / .07) * a1)
    return img


def render(n):
    t = n / FPS; img, pulse = seg(t)
    if pulse and t >= DROP and not (bar(11) < t < bar(12)):
        tb = (t - DROP) % B
        if tb > .1: img = zoom(img, 1 + .03 * math.exp(-9 * tb))
    img = captions(img, t)
    return finish(img, n, punchy=t >= DROP)
