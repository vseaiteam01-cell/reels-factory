# -*- coding: utf-8 -*-
"""Готовит видео под рецепт первого мувика: планы, кадры 720x1280 и маски героя.

    python prep.py my-video.mp4 work/

Рецепт первого мувика (трейлер GTA 6, 15.11.2026) играет 22 плана по именам:
шесть из них с вырезкой героя. Здесь эти имена получают планы из вашего видео:
смены плана находит ffmpeg, героя — маленькая модель u2netp (onnxruntime, 4,6 МБ,
без macOS и без видеокарты). Где человек крупнее всего, туда идут роли с вырезкой.
"""
import json, os, re, subprocess, sys, urllib.request
import cv2, numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
W, H, FPS = 720, 1280, 30
SPAN = 4.0                       # секунд кадров на роль: рецепт берёт до ~3,5 с
MODEL = os.path.join(HERE, "models", "u2netp.onnx")
MODEL_URL = "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx"

# Роли рецепта. С вырезкой героя: где стоп-кадр (широкая маска до этого места)
# и где маска нужна по всему плану (вертикальная, секунд).
HERO_WIDE = {"phone": 1.35, "lucia_prison": .95, "lucia_car": .34, "moto": .22}
HERO_TALL = {"jl_car": 1.7, "yellow": 1.2}
OTHER = ["jason", "highway", "roof", "kitchen", "selfie", "skyline", "club", "cop",
         "dance", "jetski", "drift", "redcar", "boat", "gym", "truckman", "lowrider"]


def say(line):
    print(line, flush=True)


def probe(path):
    p = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "stream=width,height:format=duration", "-of", "json", path],
                       capture_output=True, encoding="utf-8", errors="replace", check=True)
    d = json.loads(p.stdout)
    st = d["streams"][0]
    return int(st["width"]), int(st["height"]), float(d["format"]["duration"])


def cuts(path, dur):
    """Смены плана: ffmpeg scene-score выше 0.22. Короткие куски склеиваются."""
    p = subprocess.run(["ffmpeg", "-nostdin", "-v", "info", "-i", path, "-vf",
                        "select='gt(scene,0.22)',showinfo", "-an", "-f", "null", "-"],
                       capture_output=True, encoding="utf-8", errors="replace")
    ts = sorted(float(m) for m in re.findall(r"pts_time:([0-9.]+)", p.stderr))
    edges = [0.0] + [t for t in ts if 0.4 < t < dur - 0.4] + [dur]
    shots = []
    for a, b in zip(edges, edges[1:]):
        if shots and b - shots[-1][0] < 0.7:
            shots[-1] = (shots[-1][0], b)
        elif b - a >= 0.5:
            shots.append((a, b))
    # мало смен плана — режем длинные планы по 2,5 с, чтобы ролям хватило разных кадров
    while len(shots) < 16:
        i = max(range(len(shots)), key=lambda k: shots[k][1] - shots[k][0])
        a, b = shots[i]
        if b - a < 2.4:
            break
        shots[i:i + 1] = [(a, (a + b) / 2), ((a + b) / 2, b)]
    return shots


class Matte:
    """Маска героя: u2netp, вход 320x320, выход растягивается до кадра."""
    def __init__(self):
        if not os.path.exists(MODEL):
            os.makedirs(os.path.dirname(MODEL), exist_ok=True)
            say("    downloading the cutout model (4.6 MB), once")
            urllib.request.urlretrieve(MODEL_URL, MODEL + ".part")
            os.replace(MODEL + ".part", MODEL)
        import onnxruntime as ort
        self.s = ort.InferenceSession(MODEL, providers=["CPUExecutionProvider"])
        self.inp = self.s.get_inputs()[0].name
        self.mean = np.float32([0.485, 0.456, 0.406])
        self.std = np.float32([0.229, 0.224, 0.225])

    def __call__(self, bgr):
        x = cv2.resize(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB), (320, 320)).astype(np.float32) / 255.0
        x = ((x - self.mean) / self.std).transpose(2, 0, 1)[None]
        m = self.s.run(None, {self.inp: x})[0][0, 0]
        m = (m - m.min()) / (m.max() - m.min() + 1e-6)
        return cv2.resize(m, (bgr.shape[1], bgr.shape[0]))


def grab(path, t):
    cap = cv2.VideoCapture(path)
    cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000.0)
    ok, f = cap.read()
    cap.release()
    return f if ok else None


def hero_score(matte, frame):
    """Насколько крупно и цельно в кадре человек: площадь маски и её высота."""
    m = matte(frame) > 0.5
    if m.mean() < 0.01:
        return 0.0, 0.5
    ys, xs = np.where(m)
    height = (ys.max() - ys.min()) / float(m.shape[0])
    return float(m.mean() * 0.5 + height * 0.5), float(xs.mean() / m.shape[1])


def extract(path, src_wh, start, out_dir, cx, wide=False):
    os.makedirs(out_dir, exist_ok=True)
    sw, sh = src_wh
    if wide:
        vf = "scale=1280:-2,fps=%d" % FPS
    elif sw * 16 >= sh * 9:            # кадр шире вертикали: окно 9:16 по центру героя
        cw = int(sh * 9 / 16) // 2 * 2
        x0 = int(min(max(cx * sw - cw / 2, 0), sw - cw))
        vf = "crop=%d:%d:%d:0,scale=%d:%d,fps=%d" % (cw, sh, x0, W, H, FPS)
    else:
        vf = "scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,fps=%d" % (W, H, W, H, FPS)
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-ss", "%.3f" % start, "-t", "%.3f" % SPAN,
                    "-i", path, "-vf", vf, "-q:v", "3", "-start_number", "0",
                    os.path.join(out_dir, "%04d.jpg")], check=True)


def masks(matte, frames_dir, out_dir, upto_s):
    os.makedirs(out_dir, exist_ok=True)
    n = int(np.ceil(upto_s * FPS)) + 2
    files = sorted(f for f in os.listdir(frames_dir) if f.endswith(".jpg"))[:n]
    for f in files:
        m = matte(cv2.imread(os.path.join(frames_dir, f)))
        cv2.imwrite(os.path.join(out_dir, f[:-4] + ".png"), (m * 255).astype(np.uint8))
    return len(files)


def main(video, work):
    clips = os.path.join(work, "clips")
    os.makedirs(clips, exist_ok=True)
    sw, sh, dur = probe(video)
    shots = cuts(video, dur)
    say("    %d shots in %.1f s of video" % (len(shots), dur))
    matte = Matte()
    scored = []
    for a, b in shots:
        s, cx = hero_score(matte, grab(video, a + min(1.0, (b - a) / 2)))
        scored.append((s, cx, a, b))
    # роли с героем — планы, где человек крупнее всего; остальные — по порядку видео
    by_hero = sorted(scored, key=lambda r: -r[0])
    hero_roles = list(HERO_WIDE) + list(HERO_TALL)
    plan = {}
    for i, role in enumerate(hero_roles):
        plan[role] = by_hero[i % len(by_hero)]
    used = {id(plan[r]) for r in hero_roles}
    rest = [r for r in scored if id(r) not in used] or scored
    for i, role in enumerate(OTHER):
        plan[role] = rest[i % len(rest)]
    for role, (s, cx, a, b) in plan.items():
        extract(video, (sw, sh), a, os.path.join(clips, role), cx)
        if role in HERO_WIDE:
            extract(video, (sw, sh), a, os.path.join(clips, role + "_w"), cx, wide=True)
            masks(matte, os.path.join(clips, role + "_w"), os.path.join(clips, role + "_wm"), HERO_WIDE[role])
        if role in HERO_TALL:
            masks(matte, os.path.join(clips, role), os.path.join(clips, role + "_m"), HERO_TALL[role])
    with open(os.path.join(work, "plan.json"), "w") as f:
        json.dump({r: {"start": round(v[2], 2), "end": round(v[3], 2), "hero": round(v[0], 3)}
                   for r, v in plan.items()}, f, indent=1)
    say("    %d roles laid out on your shots" % len(plan))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
