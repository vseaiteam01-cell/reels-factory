# -*- coding: utf-8 -*-
"""Gets this machine ready for Reels Factory. Claude runs it; you do not have to.

    uv run --no-project --python 3.12 factory/prepare.py

Everything lands inside the factory folder, in .venv: Python 3.12, the libraries,
ffmpeg and node if the machine has none, the voice model. Nothing goes into
the system, and no administrator password is asked for. A second run skips
what is already in place, so after a failure you simply run it again.

The run ends with the line "READY" and the file .venv/READY, or with the list
of what did not install and why.
"""
import json, os, platform, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.abspath(__file__))
VENV = os.path.join(ROOT, ".venv")
WIN = os.name == "nt"
BIN = os.path.join(VENV, "Scripts" if WIN else "bin")
PY = os.path.join(BIN, "python.exe" if WIN else "python")
EXE = ".exe" if WIN else ""
# The free sets ship the same installer without the pipeline: they need only
# Python, numpy, OpenCV, Pillow and ffmpeg, so the light run skips speech,
# voice, node and the full check.
LIGHT = not os.path.isdir(os.path.join(ROOT, "pipeline"))
STAGES = 3 if LIGHT else 6
FAILED = []


def stage(n, title):
    print("\n[%d/%d] %s" % (n, STAGES, title), flush=True)


def ok(line):
    print("    ok    " + line, flush=True)


def bad(line):
    print("    FAIL  " + line, flush=True)
    FAILED.append(line)


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def find_uv():
    for p in (os.environ.get("UV"), shutil.which("uv"),
              os.path.expanduser("~/.local/bin/uv" + EXE),
              os.path.expanduser("~/.cargo/bin/uv" + EXE)):
        if p and os.path.exists(p):
            return p
    return None


def venv_ok():
    if not os.path.exists(PY):
        return False
    p = run([PY, "-c", "import sys; print(sys.version_info[:2])"])
    return p.returncode == 0 and "(3, 12)" in p.stdout


def pip(uv, packages):
    p = run([uv, "pip", "install", "--python", PY] + packages)
    return p.returncode == 0, (p.stderr or p.stdout).strip().splitlines()[-3:]


def has_module(name):
    return run([PY, "-c", "import %s" % name]).returncode == 0


def system_ffmpeg_ok():
    """A system ffmpeg counts only if it carries the H.264 encoder the build needs."""
    f, fp = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if not f or not fp:
        return False
    p = run([f, "-hide_banner", "-encoders"])
    return "libx264" in (p.stdout or "")


def system_node_ok():
    n, x = shutil.which("node"), shutil.which("npx")
    if not n or not x:
        return False
    p = run([n, "--version"])
    try:
        return int(p.stdout.strip().lstrip("v").split(".")[0]) >= 20
    except Exception:
        return False


def link(src, name):
    dst = os.path.join(BIN, name + EXE)
    if os.path.lexists(dst):
        os.remove(dst)
    if WIN:
        shutil.copy2(src, dst)
    else:
        os.symlink(src, dst)


def main():
    t0 = time.time()
    print("Reels Factory: getting this machine ready (%s %s)" % (platform.system(), platform.machine()))

    stage(1, "uv and Python 3.12 in .venv")
    uv = find_uv()
    if not uv:
        bad("uv not found. Install it, then run this again: "
            + ('powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"'
               if WIN else "curl -LsSf https://astral.sh/uv/install.sh | sh"))
        return finish(t0)
    if not venv_ok():
        p = run([uv, "venv", "--clear", "--python", "3.12", VENV])
        if p.returncode != 0 or not venv_ok():
            bad("could not create .venv on Python 3.12: " + (p.stderr or "").strip()[-200:])
            return finish(t0)
    ok("Python 3.12 in .venv")

    stage(2, "core libraries: numpy, opencv, pillow")
    if all(has_module(m) for m in ("numpy", "cv2", "PIL")):
        ok("already in place")
    else:
        good, tail = pip(uv, ["numpy", "opencv-python<5", "pillow"])
        ok("installed") if good else bad("core libraries: " + " / ".join(tail))

    if LIGHT:
        return light_rest(uv, t0)

    stage(3, "speech and voice libraries: faster-whisper, kokoro-onnx")
    if all(has_module(m) for m in ("faster_whisper", "kokoro_onnx", "soundfile")):
        ok("already in place")
    else:
        good, tail = pip(uv, ["faster-whisper", "kokoro-onnx", "soundfile"])
        ok("installed") if good else bad("speech libraries: " + " / ".join(tail))

    stage(4, "ffmpeg and node")
    # The project's python puts .venv's own tools first on the path, so the
    # pipeline finds ffmpeg and node here without any activation.
    p = run([PY, "-c", "import sysconfig; print(sysconfig.get_paths()['purelib'])"])
    with open(os.path.join(p.stdout.strip(), "reels_factory_path.pth"), "w") as f:
        f.write("import os, sys; os.environ['PATH'] = os.path.dirname(sys.executable) "
                "+ os.pathsep + os.environ.get('PATH', '')\n")
    if os.path.exists(os.path.join(BIN, "ffmpeg" + EXE)) or system_ffmpeg_ok():
        ok("ffmpeg in place")
    else:
        good, tail = pip(uv, ["static-ffmpeg"])
        # the package prints its download progress to the same output, so the
        # two paths are fished out by a marker
        q = run([PY, "-c", "import static_ffmpeg.run as r; "
                           "print('\\n'.join('PATH=' + x for x in "
                           "r.get_or_fetch_platform_executables_else_raise()))"])
        paths = [x[5:] for x in q.stdout.splitlines() if x.startswith("PATH=")]
        if good and q.returncode == 0 and len(paths) == 2:
            link(paths[0], "ffmpeg")
            link(paths[1], "ffprobe")
            ok("ffmpeg installed into .venv")
        else:
            bad("ffmpeg: " + ((q.stderr or "").strip()[-200:] or " / ".join(tail)))
    if os.path.exists(os.path.join(BIN, "npx" + EXE)) or system_node_ok():
        ok("node in place")
    else:
        good, tail = pip(uv, ["nodejs-wheel"])
        ok("node installed into .venv") if good else bad("node: " + " / ".join(tail))

    stage(5, "voice model (337 MB) and speech model (about 150 MB), downloaded once")
    p = run([PY, os.path.join(ROOT, "pipeline", "voiceover.py"), "--install"])
    if p.returncode == 0:
        ok("voice model in place")
    else:
        bad("voice model: " + (p.stderr or p.stdout).strip()[-200:])
    p = run([PY, "-c", "from faster_whisper import WhisperModel; "
                       "WhisperModel('base', device='cpu', compute_type='int8')"])
    ok("speech model in place") if p.returncode == 0 else bad(
        "speech model: " + (p.stderr or "").strip()[-200:])

    stage(6, "full check: tools, libraries, voice, titles, effects, a short build")
    p = run([PY, os.path.join(ROOT, "pipeline", "check.py")], cwd=ROOT, timeout=1800)
    last = [x for x in p.stdout.strip().splitlines() if x.strip()]
    print("\n".join("    " + x for x in last[-12:]))
    if p.returncode != 0 or not last or "everything in place" not in last[-1]:
        bad("check.py did not end with 'everything in place' (see the lines above)")
    return finish(t0)


def path_file():
    """The project's python puts .venv's own tools first on the path."""
    p = run([PY, "-c", "import sysconfig; print(sysconfig.get_paths()['purelib'])"])
    with open(os.path.join(p.stdout.strip(), "reels_factory_path.pth"), "w") as f:
        f.write("import os, sys; os.environ['PATH'] = os.path.dirname(sys.executable) "
                "+ os.pathsep + os.environ.get('PATH', '')\n")


def ffmpeg_in_place(uv):
    if os.path.exists(os.path.join(BIN, "ffmpeg" + EXE)) or system_ffmpeg_ok():
        ok("ffmpeg in place")
        return
    good, tail = pip(uv, ["static-ffmpeg"])
    q = run([PY, "-c", "import static_ffmpeg.run as r; "
                       "print('\\n'.join('PATH=' + x for x in "
                       "r.get_or_fetch_platform_executables_else_raise()))"])
    paths = [x[5:] for x in q.stdout.splitlines() if x.startswith("PATH=")]
    if good and q.returncode == 0 and len(paths) == 2:
        link(paths[0], "ffmpeg")
        link(paths[1], "ffprobe")
        ok("ffmpeg installed into .venv")
    else:
        bad("ffmpeg: " + ((q.stderr or "").strip()[-200:] or " / ".join(tail)))


def light_rest(uv, t0):
    stage(3, "ffmpeg and a check")
    path_file()
    ffmpeg_in_place(uv)
    p = run([PY, "-c", "import numpy, cv2, PIL, shutil; "
                       "print('libraries in place, ffmpeg:', shutil.which('ffmpeg'))"])
    if p.returncode == 0 and "None" not in p.stdout:
        ok(p.stdout.strip())
    else:
        bad("check: " + (p.stderr or p.stdout).strip()[-200:])
    return finish(t0)


def finish(t0):
    minutes = (time.time() - t0) / 60.0
    marker = os.path.join(VENV, "READY")
    if FAILED:
        if os.path.exists(marker):
            os.remove(marker)
        print("\nNOT READY after %.1f min. Failed: %d" % (minutes, len(FAILED)))
        for line in FAILED:
            print("  - " + line)
        print("Fix the cause and run prepare.py again: it skips what is already in place.")
        return 1
    with open(marker, "w") as f:
        json.dump({"date": time.strftime("%Y-%m-%d %H:%M"), "python": PY,
                   "system": platform.system(), "minutes": round(minutes, 1)}, f)
    print("\nREADY in %.1f min. Run every script with %s"
          % (minutes, os.path.relpath(PY, os.path.dirname(ROOT))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
