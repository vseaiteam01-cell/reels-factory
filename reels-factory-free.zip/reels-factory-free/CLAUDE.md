@AGENTS.md

The rules for this folder live in AGENTS.md, shared with Codex and other agents:
the line above loads them. Read them before anything else.
